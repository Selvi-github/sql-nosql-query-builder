import mysql from 'mysql2/promise';
import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Database configurations
const dbConfigs = {
  mysql: {
    host: 'localhost',
    user: 'root', 
    password: '',
    database: 'query_builder_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  },
  sqlite: {
    filename: join(__dirname, '..', '..', 'nosql_simulation.db')
  }
};

// Initialize MySQL Database
export async function initializeMySQL() {
  try {
    // First create a connection without database to create the DB if it doesn't exist
    const tempConnection = await mysql.createConnection({
      host: dbConfigs.mysql.host,
      user: dbConfigs.mysql.user,
      password: dbConfigs.mysql.password
    });

    // Create database if it doesn't exist
    await tempConnection.execute(`CREATE DATABASE IF NOT EXISTS ${dbConfigs.mysql.database}`);
    await tempConnection.end();

    console.log('✅ MySQL database created/verified');

    // Now connect with the database
    const connection = await mysql.createConnection(dbConfigs.mysql);

    // Create tables
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        age INT,
        city VARCHAR(50),
        salary DECIMAL(10, 2),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200) NOT NULL,
        price DECIMAL(10, 2),
        category VARCHAR(50),
        in_stock BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        product_id INT,
        quantity INT,
        order_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS employees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        department VARCHAR(50),
        salary DECIMAL(10, 2),
        hire_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await connection.end();
    
    console.log('✅ MySQL tables created successfully');
    return true;
  } catch (error) {
    console.error('❌ MySQL initialization error:', error);
    throw error;
  }
}

// Initialize SQLite Database (for NoSQL simulation)
export function initializeSQLite() {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(dbConfigs.sqlite.filename, (err) => {
      if (err) {
        console.error('❌ SQLite connection error:', err);
        reject(err);
        return;
      }

      console.log('✅ Connected to SQLite database');

      // Create tables for NoSQL simulation
      db.serialize(() => {
        // Users collection
        db.run(`
          CREATE TABLE IF NOT EXISTS nosql_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Products collection  
        db.run(`
          CREATE TABLE IF NOT EXISTS nosql_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Orders collection
        db.run(`
          CREATE TABLE IF NOT EXISTS nosql_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        // Customers collection
        db.run(`
          CREATE TABLE IF NOT EXISTS nosql_customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);

        console.log('✅ SQLite tables created successfully');
        resolve(db);
      });
    });
  });
}

// Get database configurations
export function getDBConfigs() {
  return dbConfigs;
}

// Test database connections
export async function testConnections() {
  try {
    // Test MySQL
    const mysqlConn = await mysql.createConnection(dbConfigs.mysql);
    await mysqlConn.execute('SELECT 1');
    await mysqlConn.end();

    // Test SQLite
    await new Promise((resolve, reject) => {
      const db = new sqlite3.Database(dbConfigs.sqlite.filename, (err) => {
        if (err) reject(err);
        db.close(() => resolve());
      });
    });

    return {
      mysql: 'connected',
      sqlite: 'connected',
      status: 'healthy'
    };
  } catch (error) {
    return {
      mysql: 'disconnected',
      sqlite: 'disconnected', 
      status: 'unhealthy',
      error: error.message
    };
  }
}