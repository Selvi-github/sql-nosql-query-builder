import mysql from 'mysql2/promise';
import sqlite3 from 'sqlite3';
import { getDBConfigs } from './init.js';

// Sample data for MySQL
const mysqlSampleData = {
  users: [
    { name: 'John Doe', email: 'john@example.com', age: 30, city: 'New York', salary: 50000.00 },
    { name: 'Jane Smith', email: 'jane@example.com', age: 25, city: 'Los Angeles', salary: 60000.00 },
    { name: 'Bob Johnson', email: 'bob@example.com', age: 35, city: 'Chicago', salary: 70000.00 },
    { name: 'Alice Brown', email: 'alice@example.com', age: 28, city: 'New York', salary: 55000.00 },
    { name: 'Charlie Wilson', email: 'charlie@example.com', age: 32, city: 'Miami', salary: 65000.00 },
    { name: 'Diana Lee', email: 'diana@example.com', age: 29, city: 'San Francisco', salary: 75000.00 },
    { name: 'Evan Garcia', email: 'evan@example.com', age: 31, city: 'Austin', salary: 68000.00 }
  ],
  
  products: [
    { name: 'Laptop', price: 999.99, category: 'Electronics', in_stock: true },
    { name: 'Smartphone', price: 699.99, category: 'Electronics', in_stock: true },
    { name: 'Desk Chair', price: 199.99, category: 'Furniture', in_stock: true },
    { name: 'Monitor', price: 299.99, category: 'Electronics', in_stock: false },
    { name: 'Keyboard', price: 79.99, category: 'Electronics', in_stock: true },
    { name: 'Mouse', price: 49.99, category: 'Electronics', in_stock: true },
    { name: 'Desk', price: 349.99, category: 'Furniture', in_stock: true },
    { name: 'Bookshelf', price: 199.99, category: 'Furniture', in_stock: false }
  ],
  
  orders: [
    { user_id: 1, product_id: 1, quantity: 1, order_date: '2024-01-15' },
    { user_id: 1, product_id: 2, quantity: 1, order_date: '2024-01-16' },
    { user_id: 2, product_id: 3, quantity: 2, order_date: '2024-01-17' },
    { user_id: 3, product_id: 4, quantity: 1, order_date: '2024-01-18' },
    { user_id: 4, product_id: 5, quantity: 3, order_date: '2024-01-19' },
    { user_id: 2, product_id: 6, quantity: 1, order_date: '2024-01-20' },
    { user_id: 5, product_id: 7, quantity: 1, order_date: '2024-01-21' },
    { user_id: 6, product_id: 8, quantity: 2, order_date: '2024-01-22' }
  ],
  
  employees: [
    { first_name: 'Michael', last_name: 'Scott', department: 'Management', salary: 80000.00, hire_date: '2020-01-15' },
    { first_name: 'Pam', last_name: 'Beesly', department: 'Admin', salary: 45000.00, hire_date: '2021-03-20' },
    { first_name: 'Jim', last_name: 'Halpert', department: 'Sales', salary: 55000.00, hire_date: '2019-11-10' },
    { first_name: 'Dwight', last_name: 'Schrute', department: 'Sales', salary: 52000.00, hire_date: '2018-07-05' },
    { first_name: 'Angela', last_name: 'Martin', department: 'Accounting', salary: 48000.00, hire_date: '2022-02-14' }
  ]
};

// Sample data for SQLite (NoSQL simulation)
const sqliteSampleData = {
  nosql_users: [
    { name: "John Doe", email: "john@example.com", age: 30, city: "New York", salary: 50000, active: true },
    { name: "Jane Smith", email: "jane@example.com", age: 25, city: "Los Angeles", salary: 60000, active: true },
    { name: "Bob Johnson", email: "bob@example.com", age: 35, city: "Chicago", salary: 70000, active: false },
    { name: "Alice Brown", email: "alice@example.com", age: 28, city: "New York", salary: 55000, active: true },
    { name: "Charlie Wilson", email: "charlie@example.com", age: 32, city: "Miami", salary: 65000, active: true }
  ],
  
  nosql_products: [
    { name: "Laptop", price: 999.99, category: "Electronics", inStock: true, features: ["8GB RAM", "256GB SSD", "Intel i5"] },
    { name: "Smartphone", price: 699.99, category: "Electronics", inStock: true, features: ["6.1-inch", "128GB", "5G"] },
    { name: "Desk Chair", price: 199.99, category: "Furniture", inStock: false, features: ["Ergonomic", "Adjustable height"] },
    { name: "Monitor", price: 299.99, category: "Electronics", inStock: true, features: ["24-inch", "1080p", "IPS"] },
    { name: "Keyboard", price: 79.99, category: "Electronics", inStock: true, features: ["Mechanical", "RGB"] }
  ],
  
  nosql_orders: [
    { user_id: 1, product_id: 1, quantity: 1, order_date: "2024-01-15", status: "delivered" },
    { user_id: 1, product_id: 2, quantity: 1, order_date: "2024-01-16", status: "shipped" },
    { user_id: 2, product_id: 3, quantity: 2, order_date: "2024-01-17", status: "pending" },
    { user_id: 3, product_id: 4, quantity: 1, order_date: "2024-01-18", status: "delivered" },
    { user_id: 4, product_id: 5, quantity: 3, order_date: "2024-01-19", status: "shipped" }
  ],
  
  nosql_customers: [
    { name: "Mike Tyson", email: "mike@example.com", tier: "premium", join_date: "2023-05-01", preferences: ["electronics", "fitness"] },
    { name: "Sarah Connor", email: "sarah@example.com", tier: "standard", join_date: "2024-01-10", preferences: ["home", "books"] },
    { name: "Bruce Wayne", email: "bruce@example.com", tier: "premium", join_date: "2022-12-15", preferences: ["electronics", "luxury"] }
  ]
};

// Insert sample data into MySQL
export async function insertMySQLSampleData() {
  try {
    const dbConfigs = getDBConfigs();
    const connection = await mysql.createConnection(dbConfigs.mysql);

    // Check if data already exists
    const [userCount] = await connection.execute('SELECT COUNT(*) as count FROM users');
    
    if (userCount[0].count === 0) {
      console.log('📥 Inserting sample data into MySQL...');
      
      // Insert users
      for (const user of mysqlSampleData.users) {
        await connection.execute(
          'INSERT INTO users (name, email, age, city, salary) VALUES (?, ?, ?, ?, ?)',
          [user.name, user.email, user.age, user.city, user.salary]
        );
      }
      
      // Insert products
      for (const product of mysqlSampleData.products) {
        await connection.execute(
          'INSERT INTO products (name, price, category, in_stock) VALUES (?, ?, ?, ?)',
          [product.name, product.price, product.category, product.in_stock]
        );
      }
      
      // Insert orders
      for (const order of mysqlSampleData.orders) {
        await connection.execute(
          'INSERT INTO orders (user_id, product_id, quantity, order_date) VALUES (?, ?, ?, ?)',
          [order.user_id, order.product_id, order.quantity, order.order_date]
        );
      }
      
      // Insert employees
      for (const employee of mysqlSampleData.employees) {
        await connection.execute(
          'INSERT INTO employees (first_name, last_name, department, salary, hire_date) VALUES (?, ?, ?, ?, ?)',
          [employee.first_name, employee.last_name, employee.department, employee.salary, employee.hire_date]
        );
      }
      
      console.log('✅ MySQL sample data inserted successfully');
    } else {
      console.log('✅ MySQL sample data already exists');
    }
    
    await connection.end();
    return true;
  } catch (error) {
    console.error('❌ MySQL sample data insertion error:', error);
    throw error;
  }
}

// Insert sample data into SQLite
export function insertSQLiteSampleData() {
  return new Promise((resolve, reject) => {
    const dbConfigs = getDBConfigs();
    const db = new sqlite3.Database(dbConfigs.sqlite.filename, (err) => {
      if (err) {
        reject(err);
        return;
      }

      // Check if data already exists
      db.get("SELECT COUNT(*) as count FROM nosql_users", (err, row) => {
        if (err) {
          db.close();
          reject(err);
          return;
        }

        if (row.count === 0) {
          console.log('📥 Inserting sample data into SQLite...');
          
          // Insert data into each collection
          Object.keys(sqliteSampleData).forEach(collectionName => {
            const stmt = db.prepare(`INSERT INTO ${collectionName} (data) VALUES (?)`);
            
            sqliteSampleData[collectionName].forEach(document => {
              stmt.run([JSON.stringify(document)]);
            });
            
            stmt.finalize();
          });
          
          console.log('✅ SQLite sample data inserted successfully');
        } else {
          console.log('✅ SQLite sample data already exists');
        }
        
        db.close((err) => {
          if (err) reject(err);
          else resolve(true);
        });
      });
    });
  });
}

// Get sample queries for testing
export function getSampleQueries() {
  return {
    sql: [
      "SELECT * FROM users;",
      "SELECT name, email FROM users WHERE age > 25;",
      "SELECT * FROM products WHERE category = 'Electronics';",
      "SELECT u.name, p.name as product_name, o.quantity FROM orders o JOIN users u ON o.user_id = u.id JOIN products p ON o.product_id = p.id;",
      "SELECT city, COUNT(*) as user_count FROM users GROUP BY city;",
      "SELECT department, AVG(salary) as avg_salary FROM employees GROUP BY department;"
    ],
    nosql: [
      "db.nosql_users.find({});",
      "db.nosql_users.find({age: {$gt: 25}});",
      "db.nosql_products.find({category: 'Electronics'});",
      "db.nosql_users.find({active: true});",
      "db.nosql_customers.find({tier: 'premium'});"
    ]
  };
}

// Clear all data (for testing/reset)
export async function clearAllData() {
  try {
    const dbConfigs = getDBConfigs();
    
    // Clear MySQL data
    const mysqlConn = await mysql.createConnection(dbConfigs.mysql);
    await mysqlConn.execute('DELETE FROM orders');
    await mysqlConn.execute('DELETE FROM users');
    await mysqlConn.execute('DELETE FROM products');
    await mysqlConn.execute('DELETE FROM employees');
    await mysqlConn.end();
    
    // Clear SQLite data
    await new Promise((resolve, reject) => {
      const db = new sqlite3.Database(dbConfigs.sqlite.filename, (err) => {
        if (err) reject(err);
        
        db.serialize(() => {
          db.run('DELETE FROM nosql_users');
          db.run('DELETE FROM nosql_products');
          db.run('DELETE FROM nosql_orders');
          db.run('DELETE FROM nosql_customers');
        });
        
        db.close((err) => {
          if (err) reject(err);
          else resolve();
        });
      });
    });
    
    console.log('🗑️ All data cleared successfully');
    return true;
  } catch (error) {
    console.error('❌ Error clearing data:', error);
    throw error;
  }
}