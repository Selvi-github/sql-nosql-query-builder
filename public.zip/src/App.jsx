import React, { useEffect, useRef, useState } from "react";
import * as Blockly from "blockly";
import "blockly/javascript";
import { javascriptGenerator } from "blockly/javascript";

function App() {
  const blocklyDiv = useRef(null);
  const workspaceRef = useRef(null);
  const [generatedCode, setGeneratedCode] = useState("");
  const [activeCategory, setActiveCategory] = useState("SQL");
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [executionResult, setExecutionResult] = useState(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [codePanelVisible, setCodePanelVisible] = useState(false);
  const [resultsPanelVisible, setResultsPanelVisible] = useState(false);
  const [chatbotVisible, setChatbotVisible] = useState(false);
  const [erDiagramVisible, setErDiagramVisible] = useState(false);
  const [erData, setErData] = useState(null);
  
  // NEW STATE FOR ER DIAGRAM WORKSPACE
  const [erWorkspaceVisible, setErWorkspaceVisible] = useState(false);
  const [erElements, setErElements] = useState([]);
  const [erConnections, setErConnections] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [connectingFrom, setConnectingFrom] = useState(null);

  // NEW STATE FOR GENERATED TABLE
  const [generatedTable, setGeneratedTable] = useState(null);

  // Initialize Blockly with ALL SQL and NoSQL blocks
  useEffect(() => {
    // Define all blocks including advanced SQL features
    Blockly.defineBlocksWithJsonArray([
      // ========== SQL DDL BLOCKS ==========
      {
        "type": "sql_create_table",
        "message0": "CREATE TABLE %1 ( %2 )",
        "args0": [
          {"type": "field_input", "name": "TABLE_NAME", "text": "users"},
          {"type": "field_input", "name": "COLUMNS", "text": "id INT, name VARCHAR(50)"}
        ],
        "colour": 230,
        "tooltip": "Create a new table"
      },
      {
        "type": "sql_alter_table",
        "message0": "ALTER TABLE %1 %2",
        "args0": [
          {"type": "field_input", "name": "TABLE_NAME", "text": "users"},
          {"type": "field_input", "name": "ACTION", "text": "ADD COLUMN email VARCHAR(100)"}
        ],
        "colour": 230,
        "tooltip": "Modify existing table"
      },
      {
        "type": "sql_drop_table",
        "message0": "DROP TABLE %1",
        "args0": [
          {"type": "field_input", "name": "TABLE_NAME", "text": "users"}
        ],
        "colour": 230,
        "tooltip": "Delete a table"
      },
      {
        "type": "sql_create_view",
        "message0": "CREATE VIEW %1 AS %2",
        "args0": [
          {"type": "field_input", "name": "VIEW_NAME", "text": "user_view"},
          {"type": "field_input", "name": "QUERY", "text": "SELECT name, city FROM users"}
        ],
        "colour": 230,
        "tooltip": "Create a view"
      },
      {
        "type": "sql_drop_view",
        "message0": "DROP VIEW %1",
        "args0": [
          {"type": "field_input", "name": "VIEW_NAME", "text": "user_view"}
        ],
        "colour": 230,
        "tooltip": "Drop a view"
      },
      {
        "type": "sql_create_sequence",
        "message0": "CREATE SEQUENCE %1",
        "args0": [
          {"type": "field_input", "name": "SEQUENCE_NAME", "text": "user_id_seq"}
        ],
        "colour": 230,
        "tooltip": "Create a sequence"
      },

      // ========== SQL DML BLOCKS ==========
      {
        "type": "sql_select",
        "message0": "SELECT %1 FROM %2 WHERE %3",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "*"},
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "CONDITION", "text": "id = 1"}
        ],
        "colour": 210,
        "tooltip": "Select data from table"
      },
      {
        "type": "sql_insert",
        "message0": "INSERT INTO %1 VALUES ( %2 )",
        "args0": [
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "VALUES", "text": "1, 'John'"}
        ],
        "colour": 210,
        "tooltip": "Insert data into table"
      },
      {
        "type": "sql_update",
        "message0": "UPDATE %1 SET %2 WHERE %3",
        "args0": [
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "SET_VALUES", "text": "name = 'Jane'"},
          {"type": "field_input", "name": "CONDITION", "text": "id = 1"}
        ],
        "colour": 210,
        "tooltip": "Update existing data"
      },
      {
        "type": "sql_delete",
        "message0": "DELETE FROM %1 WHERE %2",
        "args0": [
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "CONDITION", "text": "id = 1"}
        ],
        "colour": 210,
        "tooltip": "Delete data from table"
      },

      // ========== SQL TCL BLOCKS ==========
      {
        "type": "sql_commit",
        "message0": "COMMIT",
        "colour": 250,
        "tooltip": "Commit transaction"
      },
      {
        "type": "sql_rollback",
        "message0": "ROLLBACK",
        "colour": 250,
        "tooltip": "Rollback transaction"
      },
      {
        "type": "sql_savepoint",
        "message0": "SAVEPOINT %1",
        "args0": [
          {"type": "field_input", "name": "SAVEPOINT_NAME", "text": "sp1"}
        ],
        "colour": 250,
        "tooltip": "Create savepoint"
      },

      // ========== SQL DCL BLOCKS ==========
      {
        "type": "sql_grant",
        "message0": "GRANT %1 ON %2 TO %3",
        "args0": [
          {"type": "field_input", "name": "PRIVILEGES", "text": "SELECT, INSERT"},
          {"type": "field_input", "name": "OBJECT", "text": "users"},
          {"type": "field_input", "name": "USER", "text": "john"}
        ],
        "colour": 240,
        "tooltip": "Grant privileges"
      },
      {
        "type": "sql_revoke",
        "message0": "REVOKE %1 ON %2 FROM %3",
        "args0": [
          {"type": "field_input", "name": "PRIVILEGES", "text": "INSERT"},
          {"type": "field_input", "name": "OBJECT", "text": "users"},
          {"type": "field_input", "name": "USER", "text": "john"}
        ],
        "colour": 240,
        "tooltip": "Revoke privileges"
      },

      // ========== SQL ADVANCED BLOCKS ==========
      {
        "type": "sql_order_by",
        "message0": "SELECT %1 FROM %2 ORDER BY %3 %4",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "*"},
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "ORDER_COLUMN", "text": "name"},
          {"type": "field_dropdown", "name": "ORDER_DIRECTION", "options": [["ASC", "ASC"], ["DESC", "DESC"]]}
        ],
        "colour": 190,
        "tooltip": "Select with ordering"
      },
      {
        "type": "sql_group_by",
        "message0": "SELECT %1 FROM %2 GROUP BY %3",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "city, COUNT(*)"},
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "GROUP_COLUMN", "text": "city"}
        ],
        "colour": 190,
        "tooltip": "Group by with aggregate functions"
      },
      {
        "type": "sql_aggregate",
        "message0": "SELECT %1(%2) FROM %3",
        "args0": [
          {"type": "field_dropdown", "name": "FUNCTION", "options": [["COUNT", "COUNT"], ["SUM", "SUM"], ["AVG", "AVG"], ["MAX", "MAX"], ["MIN", "MIN"]]},
          {"type": "field_input", "name": "COLUMN", "text": "salary"},
          {"type": "field_input", "name": "TABLE", "text": "users"}
        ],
        "colour": 190,
        "tooltip": "Aggregate functions"
      },
      {
        "type": "sql_having",
        "message0": "SELECT %1 FROM %2 GROUP BY %3 HAVING %4",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "city, COUNT(*)"},
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "GROUP_COLUMN", "text": "city"},
          {"type": "field_input", "name": "HAVING_CONDITION", "text": "COUNT(*) > 1"}
        ],
        "colour": 190,
        "tooltip": "Group by with having clause"
      },
      {
        "type": "sql_subquery",
        "message0": "SELECT %1 FROM %2 WHERE %3 IN (SELECT %4 FROM %5 WHERE %6)",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "*"},
          {"type": "field_input", "name": "TABLE", "text": "users"},
          {"type": "field_input", "name": "COLUMN", "text": "id"},
          {"type": "field_input", "name": "SUB_COLUMNS", "text": "user_id"},
          {"type": "field_input", "name": "SUB_TABLE", "text": "orders"},
          {"type": "field_input", "name": "SUB_CONDITION", "text": "amount > 500"}
        ],
        "colour": 180,
        "tooltip": "Subquery with IN clause"
      },
      {
        "type": "sql_alias",
        "message0": "SELECT %1 AS %2 FROM %3",
        "args0": [
          {"type": "field_input", "name": "COLUMN", "text": "name"},
          {"type": "field_input", "name": "ALIAS", "text": "customer_name"},
          {"type": "field_input", "name": "TABLE", "text": "users"}
        ],
        "colour": 180,
        "tooltip": "Column aliasing"
      },

      // ========== SQL JOIN BLOCKS ==========
      {
        "type": "sql_inner_join",
        "message0": "SELECT %1 FROM %2 INNER JOIN %3 ON %4",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "*"},
          {"type": "field_input", "name": "TABLE1", "text": "users"},
          {"type": "field_input", "name": "TABLE2", "text": "orders"},
          {"type": "field_input", "name": "CONDITION", "text": "users.id = orders.user_id"}
        ],
        "colour": 170,
        "tooltip": "Inner join two tables"
      },
      {
        "type": "sql_left_join",
        "message0": "SELECT %1 FROM %2 LEFT JOIN %3 ON %4",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "*"},
          {"type": "field_input", "name": "TABLE1", "text": "users"},
          {"type": "field_input", "name": "TABLE2", "text": "orders"},
          {"type": "field_input", "name": "CONDITION", "text": "users.id = orders.user_id"}
        ],
        "colour": 170,
        "tooltip": "Left join two tables"
      },
      {
        "type": "sql_right_join",
        "message0": "SELECT %1 FROM %2 RIGHT JOIN %3 ON %4",
        "args0": [
          {"type": "field_input", "name": "COLUMNS", "text": "*"},
          {"type": "field_input", "name": "TABLE1", "text": "users"},
          {"type": "field_input", "name": "TABLE2", "text": "orders"},
          {"type": "field_input", "name": "CONDITION", "text": "users.id = orders.user_id"}
        ],
        "colour": 170,
        "tooltip": "Right join two tables"
      },

      // ========== SQL PROCEDURES & FUNCTIONS ==========
      {
        "type": "sql_create_procedure",
        "message0": "CREATE PROCEDURE %1 BEGIN %2 END",
        "args0": [
          {"type": "field_input", "name": "PROCEDURE_NAME", "text": "update_salary"},
          {"type": "field_input", "name": "PROCEDURE_BODY", "text": "UPDATE users SET salary = salary * 1.1 WHERE department_id = 1"}
        ],
        "colour": 160,
        "tooltip": "Create stored procedure"
      },
      {
        "type": "sql_execute_procedure",
        "message0": "EXECUTE %1",
        "args0": [
          {"type": "field_input", "name": "PROCEDURE_NAME", "text": "update_salary"}
        ],
        "colour": 160,
        "tooltip": "Execute stored procedure"
      },
      {
        "type": "sql_create_function",
        "message0": "CREATE FUNCTION %1 RETURNS %2 BEGIN %3 END",
        "args0": [
          {"type": "field_input", "name": "FUNCTION_NAME", "text": "get_avg_salary"},
          {"type": "field_dropdown", "name": "RETURN_TYPE", "options": [["INTEGER", "INTEGER"], ["VARCHAR", "VARCHAR"], ["DECIMAL", "DECIMAL"]]},
          {"type": "field_input", "name": "FUNCTION_BODY", "text": "RETURN (SELECT AVG(salary) FROM users)"}
        ],
        "colour": 160,
        "tooltip": "Create function"
      },

      // ========== SQL TRIGGERS ==========
      {
        "type": "sql_create_trigger",
        "message0": "CREATE TRIGGER %1 %2 %3 ON %4 BEGIN %5 END",
        "args0": [
          {"type": "field_input", "name": "TRIGGER_NAME", "text": "log_user_changes"},
          {"type": "field_dropdown", "name": "TRIGGER_TIME", "options": [["BEFORE", "BEFORE"], ["AFTER", "AFTER"]]},
          {"type": "field_dropdown", "name": "TRIGGER_EVENT", "options": [["INSERT", "INSERT"], ["UPDATE", "UPDATE"], ["DELETE", "DELETE"]]},
          {"type": "field_input", "name": "TABLE_NAME", "text": "users"},
          {"type": "field_input", "name": "TRIGGER_BODY", "text": "INSERT INTO audit_log VALUES (NEW.id, 'UPDATE', CURRENT_TIMESTAMP)"}
        ],
        "colour": 150,
        "tooltip": "Create trigger"
      },

      // ========== STRING FUNCTION BLOCKS ==========
      {
        "type": "sql_string_select_ucase",
        "message0": "SELECT UCASE( %1 )",
        "args0": [
          {"type": "field_input", "name": "STRING_VALUE", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Convert string to uppercase"
      },
      {
        "type": "sql_string_select_lcase",
        "message0": "SELECT LCASE( %1 )",
        "args0": [
          {"type": "field_input", "name": "STRING_VALUE", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Convert string to lowercase"
      },
      {
        "type": "sql_string_select_concat",
        "message0": "SELECT CONCAT( %1 , %2 )",
        "args0": [
          {"type": "field_input", "name": "STRING1", "text": "first_name"},
          {"type": "field_input", "name": "STRING2", "text": "last_name"}
        ],
        "colour": 130,
        "tooltip": "Concatenate two strings"
      },
      {
        "type": "sql_string_select_concat_ws",
        "message0": "SELECT CONCAT_WS( %1 , %2 , %3 )",
        "args0": [
          {"type": "field_input", "name": "SEPARATOR", "text": "' '"},
          {"type": "field_input", "name": "STRING1", "text": "first_name"},
          {"type": "field_input", "name": "STRING2", "text": "last_name"}
        ],
        "colour": 130,
        "tooltip": "Concatenate with separator"
      },
      {
        "type": "sql_string_select_substring",
        "message0": "SELECT SUBSTRING( %1 , %2 , %3 )",
        "args0": [
          {"type": "field_input", "name": "STRING", "text": "name"},
          {"type": "field_input", "name": "START", "text": "1"},
          {"type": "field_input", "name": "LENGTH", "text": "3"}
        ],
        "colour": 130,
        "tooltip": "Extract substring from string"
      },
      {
        "type": "sql_string_select_length",
        "message0": "SELECT LENGTH( %1 )",
        "args0": [
          {"type": "field_input", "name": "STRING", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Get string length"
      },
      {
        "type": "sql_string_select_char_length",
        "message0": "SELECT CHAR_LENGTH( %1 )",
        "args0": [
          {"type": "field_input", "name": "STRING", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Get character length"
      },
      {
        "type": "sql_string_select_replace",
        "message0": "SELECT REPLACE( %1 , %2 , %3 )",
        "args0": [
          {"type": "field_input", "name": "ORIGINAL", "text": "name"},
          {"type": "field_input", "name": "SEARCH", "text": "'a'"},
          {"type": "field_input", "name": "REPLACE", "text": "'b'"}
        ],
        "colour": 130,
        "tooltip": "Replace characters in string"
      },
      {
        "type": "sql_string_select_reverse",
        "message0": "SELECT REVERSE( %1 )",
        "args0": [
          {"type": "field_input", "name": "STRING", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Reverse string"
      },
      {
        "type": "sql_string_select_trim",
        "message0": "SELECT TRIM( %1 )",
        "args0": [
          {"type": "field_input", "name": "STRING", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Remove leading/trailing spaces"
      },
      {
        "type": "sql_string_select_position",
        "message0": "SELECT POSITION( %1 IN %2 )",
        "args0": [
          {"type": "field_input", "name": "SUBSTRING", "text": "'abc'"},
          {"type": "field_input", "name": "STRING", "text": "name"}
        ],
        "colour": 130,
        "tooltip": "Find position of substring"
      },

      // ========== DATE FUNCTION BLOCKS ==========
      {
        "type": "sql_date_select_now",
        "message0": "SELECT NOW()",
        "colour": 140,
        "tooltip": "Get current date and time"
      },
      {
        "type": "sql_date_select_curdate",
        "message0": "SELECT CURDATE()",
        "colour": 140,
        "tooltip": "Get current date"
      },
      {
        "type": "sql_date_select_curtime",
        "message0": "SELECT CURTIME()",
        "colour": 140,
        "tooltip": "Get current time"
      },
      {
        "type": "sql_date_select_format",
        "message0": "SELECT DATE_FORMAT( %1 , %2 )",
        "args0": [
          {"type": "field_input", "name": "DATE", "text": "created_at"},
          {"type": "field_input", "name": "FORMAT", "text": "'%Y-%m-%d'"}
        ],
        "colour": 140,
        "tooltip": "Format date"
      },
      {
        "type": "sql_date_select_datediff",
        "message0": "SELECT DATEDIFF( %1 , %2 )",
        "args0": [
          {"type": "field_input", "name": "DATE1", "text": "end_date"},
          {"type": "field_input", "name": "DATE2", "text": "start_date"}
        ],
        "colour": 140,
        "tooltip": "Difference between two dates"
      },
      {
        "type": "sql_date_select_dayname",
        "message0": "SELECT DAYNAME( %1 )",
        "args0": [
          {"type": 'field_input', "name": "DATE", "text": "created_at"}
        ],
        "colour": 140,
        "tooltip": "Get day name"
      },
      {
        "type": "sql_date_select_monthname",
        "message0": "SELECT MONTHNAME( %1 )",
        "args0": [
          {"type": "field_input", "name": "DATE", "text": "created_at"}
        ],
        "colour": 140,
        "tooltip": "Get month name"
      },
      {
        "type": "sql_date_select_year",
        "message0": "SELECT YEAR( %1 )",
        "args0": [
          {"type": "field_input", "name": "DATE", "text": "created_at"}
        ],
        "colour": 140,
        "tooltip": "Get year from date"
      },
      {
        "type": "sql_date_select_month",
        "message0": "SELECT MONTH( %1 )",
        "args0": [
          {"type": "field_input", "name": "DATE", "text": "created_at"}
        ],
        "colour": 140,
        "tooltip": "Get month from date"
      },
      {
        "type": "sql_date_select_day",
        "message0": "SELECT DAY( %1 )",
        "args0": [
          {"type": "field_input", "name": "DATE", "text": "created_at"}
        ],
        "colour": 140,
        "tooltip": "Get day from date"
      },

      // ========== NoSQL BLOCKS ==========
      {
        "type": "nosql_find",
        "message0": "db.%1.find( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "QUERY", "text": "{ age: { $gt: 18 } }"}
        ],
        "colour": 120,
        "tooltip": "Find documents in collection"
      },
      {
        "type": "nosql_insert",
        "message0": "db.%1.insert( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "DOCUMENT", "text": "{ name: 'John', age: 25 }"}
        ],
        "colour": 120,
        "tooltip": "Insert document into collection"
      },
      {
        "type": "nosql_update",
        "message0": "db.%1.update( %2 , %3 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "QUERY", "text": "{ name: 'John' }"},
          {"type": "field_input", "name": "UPDATE", "text": "{ $set: { age: 26 } }"}
        ],
        "colour": 120,
        "tooltip": "Update documents in collection"
      },
      {
        "type": "nosql_delete",
        "message0": "db.%1.remove( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "QUERY", "text": "{ name: 'John' }"}
        ],
        "colour": 120,
        "tooltip": "Remove documents from collection"
      },
      {
        "type": "nosql_aggregate",
        "message0": "db.%1.aggregate( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "PIPELINE", "text": "[ { $group: { _id: '$city', total: { $sum: 1 } } } ]"}
        ],
        "colour": 120,
        "tooltip": "Aggregate pipeline on collection"
      },
      {
        "type": "nosql_sort",
        "message0": "db.%1.find().sort( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "SORT", "text": "{ age: 1 }"}
        ],
        "colour": 120,
        "tooltip": "Sort documents"
      },
      {
        "type": "nosql_project",
        "message0": "db.%1.find( %2 , %3 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "QUERY", "text": "{}"},
          {"type": "field_input", "name": "PROJECTION", "text": "{ name: 1, age: 1 }"}
        ],
        "colour": 120,
        "tooltip": "Find with projection"
      },
      // NEW NoSQL BLOCKS
      {
        "type": "nosql_comparison",
        "message0": "db.%1.find({ %2: { %3: %4 } })",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "FIELD", "text": "age"},
          {"type": "field_dropdown", "name": "OPERATOR", "options": [["$gt", "$gt"], ["$gte", "$gte"], ["$lt", "$lt"], ["$lte", "$lte"], ["$ne", "$ne"], ["$in", "$in"], ["$nin", "$nin"]]},
          {"type": "field_input", "name": "VALUE", "text": "25"}
        ],
        "colour": 120,
        "tooltip": "Comparison operators"
      },
      {
        "type": "nosql_logical",
        "message0": "db.%1.find({ %2: [ %3 ] })",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_dropdown", "name": "OPERATOR", "options": [["$and", "$and"], ["$or", "$or"], ["$not", "$not"], ["$nor", "$nor"]]},
          {"type": "field_input", "name": "CONDITIONS", "text": "{ age: { $gt: 25 } }, { city: 'New York' }"}
        ],
        "colour": 120,
        "tooltip": "Logical query operators"
      },
      {
        "type": "nosql_element",
        "message0": "db.%1.find({ %2: { %3: %4 } })",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "FIELD", "text": "email"},
          {"type": "field_dropdown", "name": "OPERATOR", "options": [["$exists", "$exists"], ["$type", "$type"]]},
          {"type": "field_input", "name": "VALUE", "text": "true"}
        ],
        "colour": 120,
        "tooltip": "Element query operators"
      },
      {
        "type": "nosql_limit",
        "message0": "db.%1.find().limit( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "LIMIT", "text": "10"}
        ],
        "colour": 120,
        "tooltip": "Limit results"
      },
      {
        "type": "nosql_count",
        "message0": "db.%1.find().count()",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"}
        ],
        "colour": 120,
        "tooltip": "Count documents"
      },
      {
        "type": "nosql_distinct",
        "message0": "db.%1.distinct( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "FIELD", "text": "city"}
        ],
        "colour": 120,
        "tooltip": "Get distinct values"
      },
      {
        "type": "nosql_find_one",
        "message0": "db.%1.findOne( %2 )",
        "args0": [
          {"type": "field_input", "name": "COLLECTION", "text": "users"},
          {"type": "field_input", "name": "QUERY", "text": "{ name: 'John' }"}
        ],
        "colour": 120,
        "tooltip": "Find single document"
      }
    ]);

    // Setup code generators for ALL blocks
    const blockGenerators = {
      // DDL Generators
      'sql_create_table': (block) => `CREATE TABLE ${block.getFieldValue('TABLE_NAME')} (${block.getFieldValue('COLUMNS')});`,
      'sql_alter_table': (block) => `ALTER TABLE ${block.getFieldValue('TABLE_NAME')} ${block.getFieldValue('ACTION')};`,
      'sql_drop_table': (block) => `DROP TABLE ${block.getFieldValue('TABLE_NAME')};`,
      'sql_create_view': (block) => `CREATE VIEW ${block.getFieldValue('VIEW_NAME')} AS ${block.getFieldValue('QUERY')};`,
      'sql_drop_view': (block) => `DROP VIEW ${block.getFieldValue('VIEW_NAME')};`,
      'sql_create_sequence': (block) => `CREATE SEQUENCE ${block.getFieldValue('SEQUENCE_NAME')};`,

      // DML Generators
      'sql_select': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE')} WHERE ${block.getFieldValue('CONDITION')};`,
      'sql_insert': (block) => `INSERT INTO ${block.getFieldValue('TABLE')} VALUES (${block.getFieldValue('VALUES')});`,
      'sql_update': (block) => `UPDATE ${block.getFieldValue('TABLE')} SET ${block.getFieldValue('SET_VALUES')} WHERE ${block.getFieldValue('CONDITION')};`,
      'sql_delete': (block) => `DELETE FROM ${block.getFieldValue('TABLE')} WHERE ${block.getFieldValue('CONDITION')};`,

      // TCL Generators
      'sql_commit': () => `COMMIT;`,
      'sql_rollback': () => `ROLLBACK;`,
      'sql_savepoint': (block) => `SAVEPOINT ${block.getFieldValue('SAVEPOINT_NAME')};`,

      // DCL Generators
      'sql_grant': (block) => `GRANT ${block.getFieldValue('PRIVILEGES')} ON ${block.getFieldValue('OBJECT')} TO ${block.getFieldValue('USER')};`,
      'sql_revoke': (block) => `REVOKE ${block.getFieldValue('PRIVILEGES')} ON ${block.getFieldValue('OBJECT')} FROM ${block.getFieldValue('USER')};`,

      // Advanced SQL Generators
      'sql_order_by': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE')} ORDER BY ${block.getFieldValue('ORDER_COLUMN')} ${block.getFieldValue('ORDER_DIRECTION')};`,
      'sql_group_by': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE')} GROUP BY ${block.getFieldValue('GROUP_COLUMN')};`,
      'sql_aggregate': (block) => `SELECT ${block.getFieldValue('FUNCTION')}(${block.getFieldValue('COLUMN')}) FROM ${block.getFieldValue('TABLE')};`,
      'sql_having': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE')} GROUP BY ${block.getFieldValue('GROUP_COLUMN')} HAVING ${block.getFieldValue('HAVING_CONDITION')};`,
      'sql_subquery': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE')} WHERE ${block.getFieldValue('COLUMN')} IN (SELECT ${block.getFieldValue('SUB_COLUMNS')} FROM ${block.getFieldValue('SUB_TABLE')} WHERE ${block.getFieldValue('SUB_CONDITION')});`,
      'sql_alias': (block) => `SELECT ${block.getFieldValue('COLUMN')} AS ${block.getFieldValue('ALIAS')} FROM ${block.getFieldValue('TABLE')};`,

      // Join Generators
      'sql_inner_join': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE1')} INNER JOIN ${block.getFieldValue('TABLE2')} ON ${block.getFieldValue('CONDITION')};`,
      'sql_left_join': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE1')} LEFT JOIN ${block.getFieldValue('TABLE2')} ON ${block.getFieldValue('CONDITION')};`,
      'sql_right_join': (block) => `SELECT ${block.getFieldValue('COLUMNS')} FROM ${block.getFieldValue('TABLE1')} RIGHT JOIN ${block.getFieldValue('TABLE2')} ON ${block.getFieldValue('CONDITION')};`,

      // Procedure & Function Generators
      'sql_create_procedure': (block) => `CREATE PROCEDURE ${block.getFieldValue('PROCEDURE_NAME')} BEGIN ${block.getFieldValue('PROCEDURE_BODY')} END;`,
      'sql_execute_procedure': (block) => `EXECUTE ${block.getFieldValue('PROCEDURE_NAME')};`,
      'sql_create_function': (block) => `CREATE FUNCTION ${block.getFieldValue('FUNCTION_NAME')} RETURNS ${block.getFieldValue('RETURN_TYPE')} BEGIN ${block.getFieldValue('FUNCTION_BODY')} END;`,

      // Trigger Generators
      'sql_create_trigger': (block) => `CREATE TRIGGER ${block.getFieldValue('TRIGGER_NAME')} ${block.getFieldValue('TRIGGER_TIME')} ${block.getFieldValue('TRIGGER_EVENT')} ON ${block.getFieldValue('TABLE_NAME')} BEGIN ${block.getFieldValue('TRIGGER_BODY')} END;`,

      // String Function Generators
      'sql_string_select_ucase': (block) => `SELECT UCASE(${block.getFieldValue('STRING_VALUE')});`,
      'sql_string_select_lcase': (block) => `SELECT LCASE(${block.getFieldValue('STRING_VALUE')});`,
      'sql_string_select_concat': (block) => `SELECT CONCAT(${block.getFieldValue('STRING1')}, ${block.getFieldValue('STRING2')});`,
      'sql_string_select_concat_ws': (block) => `SELECT CONCAT_WS(${block.getFieldValue('SEPARATOR')}, ${block.getFieldValue('STRING1')}, ${block.getFieldValue('STRING2')});`,
      'sql_string_select_substring': (block) => `SELECT SUBSTRING(${block.getFieldValue('STRING')}, ${block.getFieldValue('START')}, ${block.getFieldValue('LENGTH')});`,
      'sql_string_select_length': (block) => `SELECT LENGTH(${block.getFieldValue('STRING')});`,
      'sql_string_select_char_length': (block) => `SELECT CHAR_LENGTH(${block.getFieldValue('STRING')});`,
      'sql_string_select_replace': (block) => `SELECT REPLACE(${block.getFieldValue('ORIGINAL')}, ${block.getFieldValue('SEARCH')}, ${block.getFieldValue('REPLACE')});`,
      'sql_string_select_reverse': (block) => `SELECT REVERSE(${block.getFieldValue('STRING')});`,
      'sql_string_select_trim': (block) => `SELECT TRIM(${block.getFieldValue('STRING')});`,
      'sql_string_select_position': (block) => `SELECT POSITION(${block.getFieldValue('SUBSTRING')} IN ${block.getFieldValue('STRING')});`,

      // Date Function Generators
      'sql_date_select_now': () => `SELECT NOW();`,
      'sql_date_select_curdate': () => `SELECT CURDATE();`,
      'sql_date_select_curtime': () => `SELECT CURTIME();`,
      'sql_date_select_format': (block) => `SELECT DATE_FORMAT(${block.getFieldValue('DATE')}, ${block.getFieldValue('FORMAT')});`,
      'sql_date_select_datediff': (block) => `SELECT DATEDIFF(${block.getFieldValue('DATE1')}, ${block.getFieldValue('DATE2')});`,
      'sql_date_select_dayname': (block) => `SELECT DAYNAME(${block.getFieldValue('DATE')});`,
      'sql_date_select_monthname': (block) => `SELECT MONTHNAME(${block.getFieldValue('DATE')});`,
      'sql_date_select_year': (block) => `SELECT YEAR(${block.getFieldValue('DATE')});`,
      'sql_date_select_month': (block) => `SELECT MONTH(${block.getFieldValue('DATE')});`,
      'sql_date_select_day': (block) => `SELECT DAY(${block.getFieldValue('DATE')});`,

      // NoSQL Generators
      'nosql_find': (block) => `db.${block.getFieldValue('COLLECTION')}.find(${block.getFieldValue('QUERY')});`,
      'nosql_insert': (block) => `db.${block.getFieldValue('COLLECTION')}.insert(${block.getFieldValue('DOCUMENT')});`,
      'nosql_update': (block) => `db.${block.getFieldValue('COLLECTION')}.update(${block.getFieldValue('QUERY')}, ${block.getFieldValue('UPDATE')});`,
      'nosql_delete': (block) => `db.${block.getFieldValue('COLLECTION')}.remove(${block.getFieldValue('QUERY')});`,
      'nosql_aggregate': (block) => `db.${block.getFieldValue('COLLECTION')}.aggregate(${block.getFieldValue('PIPELINE')});`,
      'nosql_sort': (block) => `db.${block.getFieldValue('COLLECTION')}.find().sort(${block.getFieldValue('SORT')});`,
      'nosql_project': (block) => `db.${block.getFieldValue('COLLECTION')}.find(${block.getFieldValue('QUERY')}, ${block.getFieldValue('PROJECTION')});`,
      
      // NEW NoSQL Generators
      'nosql_comparison': (block) => `db.${block.getFieldValue('COLLECTION')}.find({ ${block.getFieldValue('FIELD')}: { ${block.getFieldValue('OPERATOR')}: ${block.getFieldValue('VALUE')} });`,
      'nosql_logical': (block) => `db.${block.getFieldValue('COLLECTION')}.find({ ${block.getFieldValue('OPERATOR')}: [ ${block.getFieldValue('CONDITIONS')} ] });`,
      'nosql_element': (block) => `db.${block.getFieldValue('COLLECTION')}.find({ ${block.getFieldValue('FIELD')}: { ${block.getFieldValue('OPERATOR')}: ${block.getFieldValue('VALUE')} });`,
      'nosql_limit': (block) => `db.${block.getFieldValue('COLLECTION')}.find().limit(${block.getFieldValue('LIMIT')});`,
      'nosql_count': (block) => `db.${block.getFieldValue('COLLECTION')}.find().count();`,
      'nosql_distinct': (block) => `db.${block.getFieldValue('COLLECTION')}.distinct(${block.getFieldValue('FIELD')});`,
      'nosql_find_one': (block) => `db.${block.getFieldValue('COLLECTION')}.findOne(${block.getFieldValue('QUERY')});`
    };

    // Register all generators
    Object.keys(blockGenerators).forEach(blockType => {
      javascriptGenerator.forBlock[blockType] = blockGenerators[blockType];
    });

    // Initialize workspace with proper configuration for visibility
    if (blocklyDiv.current) {
      workspaceRef.current = Blockly.inject(blocklyDiv.current, {
        toolbox: getToolboxXML(),
        theme: Blockly.Themes.Dark,
        scrollbars: true,
        trashcan: true,
        horizontalLayout: false,
        toolboxPosition: 'start',
        renderer: 'zelos',
        zoom: {
          controls: true,
          wheel: true,
          startScale: 1.0,
          maxScale: 3,
          minScale: 0.3,
          scaleSpeed: 1.2
        },
        move: {
          scrollbars: {
            horizontal: true,
            vertical: true
          },
          drag: true,
          wheel: true
        },
        grid: {
          spacing: 20,
          length: 3,
          colour: '#ccc',
          snap: true
        }
      });

      // Force refresh the workspace
      setTimeout(() => {
        if (workspaceRef.current) {
          workspaceRef.current.render();
        }
      }, 100);

      // Update code when blocks change
      workspaceRef.current.addChangeListener(() => {
        const code = javascriptGenerator.workspaceToCode(workspaceRef.current);
        setGeneratedCode(code);
      });
    }

    return () => {
      if (workspaceRef.current) {
        workspaceRef.current.dispose();
      }
    };
  }, []);

  // Update toolbox when category changes
  useEffect(() => {
    if (workspaceRef.current) {
      workspaceRef.current.updateToolbox(getToolboxXML());
      // Force re-render after toolbox update
      setTimeout(() => {
        if (workspaceRef.current) {
          workspaceRef.current.render();
        }
      }, 50);
    }
  }, [activeCategory]);

  const getToolboxXML = () => {
    if (activeCategory === "SQL") {
      return `
        <xml xmlns="https://developers.google.com/blockly/xml">
          <category name=" DDL Commands" colour="230">
            <block type="sql_create_table"></block>
            <block type="sql_alter_table"></block>
            <block type="sql_drop_table"></block>
            <block type="sql_create_view"></block>
            <block type="sql_drop_view"></block>
            <block type="sql_create_sequence"></block>
          </category>
          <category name=" DML Commands" colour="210">
            <block type="sql_select"></block>
            <block type="sql_insert"></block>
            <block type="sql_update"></block>
            <block type="sql_delete"></block>
          </category>
          <category name=" TCL Commands" colour="250">
            <block type="sql_commit"></block>
            <block type="sql_rollback"></block>
            <block type="sql_savepoint"></block>
          </category>
          <category name=" DCL Commands" colour="240">
            <block type="sql_grant"></block>
            <block type="sql_revoke"></block>
          </category>
          <category name=" Advanced SQL" colour="190">
            <block type="sql_order_by"></block>
            <block type="sql_group_by"></block>
            <block type="sql_aggregate"></block>
            <block type="sql_having"></block>
            <block type="sql_subquery"></block>
            <block type="sql_alias"></block>
          </category>
          <category name=" JOIN Operations" colour="170">
            <block type="sql_inner_join"></block>
            <block type="sql_left_join"></block>
            <block type="sql_right_join"></block>
          </category>
          <category name=" String Functions" colour="130">
            <block type="sql_string_select_ucase"></block>
            <block type="sql_string_select_lcase"></block>
            <block type="sql_string_select_concat"></block>
            <block type="sql_string_select_concat_ws"></block>
            <block type="sql_string_select_substring"></block>
            <block type="sql_string_select_length"></block>
            <block type="sql_string_select_char_length"></block>
            <block type="sql_string_select_replace"></block>
            <block type="sql_string_select_reverse"></block>
            <block type="sql_string_select_trim"></block>
            <block type="sql_string_select_position"></block>
          </category>
          <category name=" Date Functions" colour="140">
            <block type="sql_date_select_now"></block>
            <block type="sql_date_select_curdate"></block>
            <block type="sql_date_select_curtime"></block>
            <block type="sql_date_select_format"></block>
            <block type="sql_date_select_datediff"></block>
            <block type="sql_date_select_dayname"></block>
            <block type="sql_date_select_monthname"></block>
            <block type="sql_date_select_year"></block>
            <block type="sql_date_select_month"></block>
            <block type="sql_date_select_day"></block>
          </category>
          <category name=" Procedures & Functions" colour="160">
            <block type="sql_create_procedure"></block>
            <block type="sql_execute_procedure"></block>
            <block type="sql_create_function"></block>
          </category>
          <category name=" Triggers" colour="150">
            <block type="sql_create_trigger"></block>
          </category>
        </xml>
      `;
    } else {
      return `
        <xml xmlns="https://developers.google.com/blockly/xml">
          <category name=" CRUD Operations" colour="120">
            <block type="nosql_find"></block>
            <block type="nosql_insert"></block>
            <block type="nosql_update"></block>
            <block type="nosql_delete"></block>
            <block type="nosql_find_one"></block>
          </category>
          <category name=" Query Options" colour="110">
            <block type="nosql_sort"></block>
            <block type="nosql_project"></block>
            <block type="nosql_limit"></block>
            <block type="nosql_count"></block>
            <block type="nosql_distinct"></block>
          </category>
          <category name=" Aggregation" colour="100">
            <block type="nosql_aggregate"></block>
          </category>
          <category name=" Comparison Operators" colour="90">
            <block type="nosql_comparison"></block>
          </category>
          <category name=" Logical Operators" colour="80">
            <block type="nosql_logical"></block>
          </category>
          <category name=" Element Operators" colour="70">
            <block type="nosql_element"></block>
          </category>
        </xml>
      `;
    }
  };

  // Parse SQL code to extract table structure - UPDATED FOR BETTER PARSING
  const parseSQLToER = () => {
    if (!generatedCode.trim()) {
      alert("No code generated! Please build a query first.");
      return null;
    }

    const tables = [];
    const relationships = [];

    // Enhanced CREATE TABLE parsing
    const createTableRegex = /CREATE TABLE\s+(\w+)\s*\(([^;]+)\)/gi;
    let match;

    while ((match = createTableRegex.exec(generatedCode)) !== null) {
      const tableName = match[1];
      const columnsText = match[2];
      
      const columns = columnsText.split(',').map(col => {
        const cleanCol = col.trim();
        const colMatch = cleanCol.match(/^(\w+)\s+([\w\(\)\s]+)/);
        if (colMatch) {
          return {
            name: colMatch[1].trim(),
            type: colMatch[2].trim(),
            isPrimary: cleanCol.includes('PRIMARY KEY') || /PRIMARY\s+KEY/i.test(cleanCol),
            isForeign: cleanCol.includes('FOREIGN KEY') || cleanCol.includes('REFERENCES')
          };
        }
        return null;
      }).filter(Boolean);

      tables.push({
        name: tableName,
        columns: columns
      });

      // Enhanced foreign key relationship parsing
      const foreignKeyRegex = /FOREIGN\s+KEY\s*\(([^)]+)\)\s*REFERENCES\s*(\w+)\s*\(([^)]+)\)/gi;
      let fkMatch;
      while ((fkMatch = foreignKeyRegex.exec(columnsText)) !== null) {
        relationships.push({
          fromTable: tableName,
          fromColumn: fkMatch[1].trim(),
          toTable: fkMatch[2].trim(),
          toColumn: fkMatch[3].trim()
        });
      }
    }

    return { tables, relationships };
  };

  // Generate ER Diagram - UPDATED FOR BETTER VISUALIZATION
  const generateERDiagram = () => {
    const parsedData = parseSQLToER();
    if (parsedData) {
      setErData(parsedData);
      setErDiagramVisible(true);
    }
  };

  // Clear Diagram
  const clearDiagram = () => {
    setErData(null);
  };

  // NEW FUNCTION: Convert ER Diagram to SQL Tables
  const convertERToTables = () => {
    if (!erElements.length) {
      alert("No ER elements found! Please create an ER diagram first.");
      return;
    }

    let sqlCode = "";
    const tables = [];
    
    // Group attributes by entity
    const entities = erElements.filter(el => el.type === 'entity');
    const attributes = erElements.filter(el => el.type === 'attribute');
    const relationships = erElements.filter(el => el.type === 'relationship');

    entities.forEach(entity => {
      const entityAttrs = attributes.filter(attr => 
        erConnections.some(conn => 
          conn.from === attr.id && conn.to === entity.id
        )
      );

      if (entityAttrs.length > 0) {
        const tableName = entity.name || 'untitled_entity';
        sqlCode += `CREATE TABLE ${tableName} (\n`;
        
        const columns = entityAttrs.map(attr => {
          let columnDef = `  ${attr.name || 'untitled_attr'} ${attr.dataType || 'VARCHAR(255)'}`;
          if (attr.isPrimary) columnDef += ' PRIMARY KEY';
          if (attr.isNotNull) columnDef += ' NOT NULL';
          if (attr.isUnique) columnDef += ' UNIQUE';
          return columnDef;
        });

        // Add foreign keys from relationships
        relationships.forEach(rel => {
          if (rel.fromEntity === entity.id && rel.toEntity) {
            const toEntity = entities.find(e => e.id === rel.toEntity);
            if (toEntity) {
              columns.push(`  FOREIGN KEY (${rel.name || 'fk_column'}) REFERENCES ${toEntity.name || 'untitled_entity'}(id)`);
            }
          }
        });

        sqlCode += columns.join(',\n');
        sqlCode += '\n);\n\n';

        // Store table data for display
        tables.push({
          name: tableName,
          columns: entityAttrs.map(attr => ({
            name: attr.name || 'untitled_attr',
            type: attr.dataType || 'VARCHAR(255)',
            isPrimary: attr.isPrimary,
            isNotNull: attr.isNotNull,
            isUnique: attr.isUnique
          }))
        });
      }
    });

    // Update the generated code with the SQL
    setGeneratedCode(sqlCode);
    setGeneratedTable(tables);
    setCodePanelVisible(true);
    alert("ER Diagram converted to SQL tables! Check the code panel.");
  };

  // NEW FUNCTION: Add ER Element
  const addERElement = (type, x, y) => {
    const newElement = {
      id: `er-${Date.now()}`,
      type: type,
      x: x,
      y: y,
      name: type === 'entity' ? `Entity_${erElements.filter(el => el.type === 'entity').length + 1}` : 
           type === 'attribute' ? `Attribute_${erElements.filter(el => el.type === 'attribute').length + 1}` :
           `Relationship_${erElements.filter(el => el.type === 'relationship').length + 1}`,
      dataType: type === 'attribute' ? 'VARCHAR(255)' : '',
      isPrimary: false,
      isNotNull: false,
      isUnique: false
    };
    
    setErElements(prev => [...prev, newElement]);
    return newElement;
  };

  // NEW FUNCTION: Handle Element Drag Start
  const handleElementDragStart = (e, elementId) => {
    setIsDragging(true);
    setSelectedElement(elementId);
    
    const element = erElements.find(el => el.id === elementId);
    if (element) {
      const rect = e.target.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  };

  // NEW FUNCTION: Handle Element Drag
  const handleElementDrag = (e) => {
    if (!isDragging || !selectedElement) return;

    const workspaceRect = document.getElementById('er-workspace').getBoundingClientRect();
    const x = e.clientX - workspaceRect.left - dragOffset.x;
    const y = e.clientY - workspaceRect.top - dragOffset.y;

    setErElements(prev => 
      prev.map(el => 
        el.id === selectedElement 
          ? { ...el, x: Math.max(0, x), y: Math.max(0, y) }
          : el
      )
    );
  };

  // NEW FUNCTION: Handle Element Drag End
  const handleElementDragEnd = () => {
    setIsDragging(false);
    setSelectedElement(null);
  };

  // NEW FUNCTION: Update Element Property
  const updateElementProperty = (elementId, property, value) => {
    setErElements(prev =>
      prev.map(el =>
        el.id === elementId ? { ...el, [property]: value } : el
      )
    );
  };

  // NEW FUNCTION: Delete Element
  const deleteElement = (elementId) => {
    setErElements(prev => prev.filter(el => el.id !== elementId));
    setErConnections(prev => prev.filter(conn => 
      conn.from !== elementId && conn.to !== elementId
    ));
  };

  // NEW FUNCTION: Add Connection
  const addConnection = (fromId, toId) => {
    const newConnection = {
      id: `conn-${Date.now()}`,
      from: fromId,
      to: toId
    };
    setErConnections(prev => [...prev, newConnection]);
  };

  // NEW FUNCTION: Start Connection
  const startConnection = (elementId) => {
    setConnectingFrom(elementId);
  };

  // NEW FUNCTION: Complete Connection
  const completeConnection = (toId) => {
    if (connectingFrom && connectingFrom !== toId) {
      addConnection(connectingFrom, toId);
    }
    setConnectingFrom(null);
  };

  // NEW FUNCTION: Clear ER Workspace
  const clearERWorkspace = () => {
    setErElements([]);
    setErConnections([]);
    setConnectingFrom(null);
    setGeneratedTable(null);
  };

  // NEW FUNCTION: Render Generated Table
  const renderGeneratedTable = () => {
    if (!generatedTable || generatedTable.length === 0) {
      return (
        <div style={styles.noTable}>
          <div style={styles.noTableIcon}>📊</div>
          <div style={styles.noTableText}>
            No tables generated yet.
            <br />
            Click "Generate Tables" to convert your ER diagram to SQL tables.
          </div>
        </div>
      );
    }

    return (
      <div style={styles.generatedTableContainer}>
        <h3 style={styles.generatedTableTitle}>Generated Tables</h3>
        {generatedTable.map((table, index) => (
          <div key={index} style={styles.tableCard}>
            <div style={styles.tableHeader}>
              <div style={styles.tableName}>
                <span style={styles.tableIcon}>📋</span>
                {table.name}
              </div>
              <div style={styles.tableType}>TABLE</div>
            </div>
            <div style={styles.tableColumns}>
              <div style={styles.columnHeader}>
                <span>Column Name</span>
                <span>Data Type</span>
                <span>Constraints</span>
              </div>
              {table.columns.map((column, colIndex) => (
                <div key={colIndex} style={styles.columnRow}>
                  <span style={styles.columnName}>{column.name}</span>
                  <span style={styles.columnType}>{column.type}</span>
                  <span style={styles.columnConstraints}>
                    {column.isPrimary && <span style={styles.constraintPk}>PK</span>}
                    {column.isNotNull && <span style={styles.constraintNn}>NN</span>}
                    {column.isUnique && <span style={styles.constraintUq}>UQ</span>}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };
// PROPERLY FIXED ER DIAGRAM FUNCTION
const renderMindMapERDiagram = () => {
  if (!erData || !erData.tables.length) {
    return (
      <div style={styles.noVisualization}>
        <div style={styles.noVisualizationIcon}>🧠</div>
        <div style={styles.noVisualizationText}>
          No tables found in the generated code.
          <br />
          Create tables using CREATE TABLE blocks to see the ER diagram.
        </div>
      </div>
    );
  }

  return (
    <div style={styles.erDiagramContainer}>
      <div style={styles.erDiagram}>
        
        {/* CENTER DATABASE NODE */}
        <div style={styles.centerNode}>
          <div style={styles.databaseDiamond}>
            <div style={styles.databaseDiamondContent}>
              <div style={styles.databaseIcon}>🗃️</div>
              <div style={styles.databaseText}>DATABASE</div>
            </div>
          </div>
        </div>

        {/* ALL CONNECTIONS IN ONE SVG */}
        <svg style={styles.allConnections}>
          <defs>
            <marker id="dbArrow" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6" />
            </marker>
            <marker id="attrArrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
              <polygon points="0 0, 8 3, 0 6" fill="#10b981" />
            </marker>
            <marker id="relArrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
              <polygon points="0 0, 8 3, 0 6" fill="#f59e0b" />
            </marker>
          </defs>

          {/* DATABASE TO TABLE CONNECTIONS */}
          {erData.tables.map((table, index) => {
            const angle = (index / erData.tables.length) * 2 * Math.PI;
            const radius = 250;
            const centerX = 500;
            const centerY = 400;
            const tableX = centerX + radius * Math.cos(angle);
            const tableY = centerY + radius * Math.sin(angle);
            
            return (
              <line
                key={`db-${table.name}`}
                x1={centerX}
                y1={centerY}
                x2={tableX}
                y2={tableY}
                stroke="#3b82f6"
                strokeWidth="2"
                markerEnd="url(#dbArrow)"
              />
            );
          })}

          {/* TABLE TO ATTRIBUTE CONNECTIONS */}
          {erData.tables.map((table, index) => {
            const angle = (index / erData.tables.length) * 2 * Math.PI;
            const radius = 250;
            const centerX = 500;
            const centerY = 400;
            const tableX = centerX + radius * Math.cos(angle);
            const tableY = centerY + radius * Math.sin(angle);
            
            return table.columns.map((column, colIndex) => {
              const totalAttributes = table.columns.length;
              const attrAngle = angle + (-Math.PI/3 + (colIndex / Math.max(1, totalAttributes - 1)) * (Math.PI/1.5));
              const attrRadius = 150;
              const attrX = tableX + attrRadius * Math.cos(attrAngle);
              const attrY = tableY + attrRadius * Math.sin(attrAngle);
              
              return (
                <line
                  key={`${table.name}-${column.name}-conn`}
                  x1={tableX}
                  y1={tableY}
                  x2={attrX}
                  y2={attrY}
                  stroke="#10b981"
                  strokeWidth="1.5"
                  markerEnd="url(#attrArrow)"
                />
              );
            });
          })}

          {/* TABLE RELATIONSHIPS */}
          {erData.relationships.map((rel, index) => {
            const fromTable = erData.tables.find(t => t.name === rel.fromTable);
            const toTable = erData.tables.find(t => t.name === rel.toTable);
            
            if (!fromTable || !toTable) return null;
            
            const fromIndex = erData.tables.indexOf(fromTable);
            const toIndex = erData.tables.indexOf(toTable);
            
            const fromAngle = (fromIndex / erData.tables.length) * 2 * Math.PI;
            const toAngle = (toIndex / erData.tables.length) * 2 * Math.PI;
            const radius = 250;
            const centerX = 500;
            const centerY = 400;
            
            const fromX = centerX + radius * Math.cos(fromAngle);
            const fromY = centerY + radius * Math.sin(fromAngle);
            const toX = centerX + radius * Math.cos(toAngle);
            const toY = centerY + radius * Math.sin(toAngle);
            
            const midX = (fromX + toX) / 2;
            const midY = (fromY + toY) / 2;
            const dx = toX - fromX;
            const dy = toY - fromY;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const offset = Math.min(100, distance * 0.4);
            
            const controlX = midX + (-dy / distance) * offset;
            const controlY = midY + (dx / distance) * offset;
            
            return (
              <g key={index}>
                <path
                  d={`M ${fromX} ${fromY} Q ${controlX} ${controlY} ${toX} ${toY}`}
                  stroke="#f59e0b"
                  strokeWidth="2"
                  fill="none"
                  strokeDasharray="4,3"
                  markerEnd="url(#relArrow)"
                />
              </g>
            );
          })}
        </svg>

        {/* TABLE NODES */}
        {erData.tables.map((table, index) => {
          const angle = (index / erData.tables.length) * 2 * Math.PI;
          const radius = 250;
          const centerX = 500;
          const centerY = 400;
          const tableX = centerX + radius * Math.cos(angle);
          const tableY = centerY + radius * Math.sin(angle);
          
          return (
            <div key={table.name} style={{
              position: 'absolute',
              left: tableX,
              top: tableY,
              transform: 'translate(-50%, -50%)',
              zIndex: 20
            }}>
              {/* TABLE NAME BOX */}
              <div style={styles.tableBox}>
                <div style={styles.tableIcon}>📊</div>
                <div style={styles.tableName}>{table.name}</div>
              </div>
            </div>
          );
        })}

        {/* ATTRIBUTE NODES */}
        {erData.tables.map((table, index) => {
          const angle = (index / erData.tables.length) * 2 * Math.PI;
          const radius = 250;
          const centerX = 500;
          const centerY = 400;
          const tableX = centerX + radius * Math.cos(angle);
          const tableY = centerY + radius * Math.sin(angle);
          
          return table.columns.map((column, colIndex) => {
            const totalAttributes = table.columns.length;
            const attrAngle = angle + (-Math.PI/3 + (colIndex / Math.max(1, totalAttributes - 1)) * (Math.PI/1.5));
            const attrRadius = 150;
            const attrX = tableX + attrRadius * Math.cos(attrAngle);
            const attrY = tableY + attrRadius * Math.sin(attrAngle);
            
            return (
              <div key={`${table.name}-${column.name}`} 
                style={{
                  ...styles.attributeBox,
                  position: 'absolute',
                  left: attrX,
                  top: attrY,
                  transform: 'translate(-50%, -50%)'
                }}>
                <div style={styles.attributeContent}>
                  <div style={styles.attributeName}>{column.name}</div>
                  <div style={styles.attributeType}>{column.type}</div>
                  <div style={styles.attributeIcons}>
                    {column.isPrimary && <span style={styles.pkIcon}>🔑</span>}
                    {column.isForeign && <span style={styles.fkIcon}>🔗</span>}
                  </div>
                </div>
              </div>
            );
          });
        })}
      </div>

      {/* LEGEND */}
      <div style={styles.legend}>
        <div style={styles.legendTitle}>ER Diagram Legend</div>
        <div style={styles.legendItems}>
          <div style={styles.legendItem}>
            <div style={{...styles.legendColor, backgroundColor: '#3b82f6'}}></div>
            <span>Database → Tables</span>
          </div>
          <div style={styles.legendItem}>
            <div style={{...styles.legendColor, backgroundColor: '#10b981'}}></div>
            <span>Tables → Attributes</span>
          </div>
          <div style={styles.legendItem}>
            <div style={{...styles.legendColor, backgroundColor: '#f59e0b'}}></div>
            <span>Table Relationships</span>
          </div>
          <div style={styles.legendItem}>
            <span style={styles.legendIcon}>🔑</span>
            <span>Primary Key</span>
          </div>
          <div style={styles.legendItem}>
            <span style={styles.legendIcon}>🔗</span>
            <span>Foreign Key</span>
          </div>
        </div>
      </div>
    </div>
  );
};


  // UPDATED FUNCTION: Render ER Diagram Workspace with Table on Right Side
  const renderERWorkspace = () => {
    return (
      <div style={styles.erWorkspaceContainer}>
        {/* TOOLBAR */}
        <div style={styles.erToolbar}>
          <h3 style={styles.erToolbarTitle}>ER Diagram Tools</h3>
          <div style={styles.erTools}>
            <div style={styles.toolCategory}>
              <div style={styles.toolCategoryTitle}>Entities & Attributes</div>
              <div style={styles.toolButtons}>
                <button 
                  style={styles.toolButton}
                  onClick={() => addERElement('entity', 100, 100)}
                >
                  <div style={styles.entitySymbol}>□</div>
                  Add Entity
                </button>
                <button 
                  style={styles.toolButton}
                  onClick={() => addERElement('attribute', 200, 100)}
                >
                  <div style={styles.attributeSymbol}>○</div>
                  Add Attribute
                </button>
                <button 
                  style={styles.toolButton}
                  onClick={() => addERElement('relationship', 300, 100)}
                >
                  <div style={styles.relationshipSymbol}>◇</div>
                  Add Relationship
                </button>
              </div>
            </div>
            
            <div style={styles.toolCategory}>
              <div style={styles.toolCategoryTitle}>Actions</div>
              <div style={styles.toolButtons}>
                <button 
                  style={{...styles.toolButton, backgroundColor: '#10b981'}}
                  onClick={convertERToTables}
                >
                  📊 Generate Tables
                </button>
                <button 
                  style={{...styles.toolButton, backgroundColor: '#ef4444'}}
                  onClick={clearERWorkspace}
                >
                  🗑️ Clear All
                </button>
                <button 
                  style={{...styles.toolButton, backgroundColor: '#6b7280'}}
                  onClick={() => setErWorkspaceVisible(false)}
                >
                  ← Back
                </button>
              </div>
            </div>

            <div style={styles.toolCategory}>
              <div style={styles.toolCategoryTitle}>Connection Mode</div>
              <div style={styles.toolButtons}>
                <button 
                  style={{
                    ...styles.toolButton, 
                    backgroundColor: connectingFrom ? '#3b82f6' : '#374151'
                  }}
                  onClick={() => setConnectingFrom(connectingFrom ? null : 'start')}
                >
                  🔗 {connectingFrom ? 'Connecting...' : 'Start Connection'}
                </button>
                {connectingFrom && (
                  <div style={styles.connectionHint}>
                    Click on an element to start connection, then click on another element to connect
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* WORKSPACE AND TABLE CONTAINER */}
        <div style={styles.workspaceAndTable}>
          {/* WORKSPACE */}
          <div 
            id="er-workspace"
            style={{
              ...styles.erWorkspace,
              cursor: isDragging ? 'grabbing' : (connectingFrom ? 'crosshair' : 'default')
            }}
            onMouseMove={handleElementDrag}
            onMouseUp={handleElementDragEnd}
            onMouseLeave={handleElementDragEnd}
          >
            {/* GRID BACKGROUND */}
            <div style={styles.workspaceGrid}></div>

            {/* CONNECTIONS */}
            <svg style={styles.erConnections}>
              <defs>
                <marker
                  id="connectionArrow"
                  markerWidth="8"
                  markerHeight="6"
                  refX="7"
                  refY="3"
                  orient="auto"
                >
                  <polygon points="0 0, 8 3, 0 6" fill="#94a3b8" />
                </marker>
              </defs>
              {erConnections.map(conn => {
                const fromEl = erElements.find(el => el.id === conn.from);
                const toEl = erElements.find(el => el.id === conn.to);
                
                if (!fromEl || !toEl) return null;
                
                // Calculate connection points based on element type and position
                const fromPoint = getElementConnectionPoint(fromEl);
                const toPoint = getElementConnectionPoint(toEl);
                
                return (
                  <line
                    key={conn.id}
                    x1={fromPoint.x}
                    y1={fromPoint.y}
                    x2={toPoint.x}
                    y2={toPoint.y}
                    stroke="#94a3b8"
                    strokeWidth="2"
                    markerEnd="url(#connectionArrow)"
                  />
                );
              })}
              
              {/* Temporary connection line when connecting */}
              {connectingFrom && typeof connectingFrom === 'string' && selectedElement && (
                (() => {
                  const fromEl = erElements.find(el => el.id === connectingFrom);
                  const toEl = erElements.find(el => el.id === selectedElement);
                  
                  if (!fromEl || !toEl) return null;
                  
                  const fromPoint = getElementConnectionPoint(fromEl);
                  const toPoint = getElementConnectionPoint(toEl);
                  
                  return (
                    <line
                      x1={fromPoint.x}
                      y1={fromPoint.y}
                      x2={toPoint.x}
                      y2={toPoint.y}
                      stroke="#3b82f6"
                      strokeWidth="2"
                      strokeDasharray="4,2"
                    />
                  );
                })()
              )}
            </svg>

            {/* ER ELEMENTS */}
            {erElements.map(element => (
              <div
                key={element.id}
                style={{
                  ...styles.erElement,
                  ...(element.type === 'entity' ? styles.entityElement : {}),
                  ...(element.type === 'attribute' ? styles.attributeElement : {}),
                  ...(element.type === 'relationship' ? styles.relationshipElement : {}),
                  left: element.x,
                  top: element.y,
                  border: selectedElement === element.id ? '2px solid #3b82f6' : 
                         element.type === 'entity' ? '2px solid #7e22ce' :
                         element.type === 'attribute' ? '2px solid #059669' :
                         '2px solid #f59e0b',
                  cursor: connectingFrom ? 'pointer' : 'grab'
                }}
                onMouseDown={(e) => {
                  if (connectingFrom) {
                    if (connectingFrom === 'start') {
                      setConnectingFrom(element.id);
                    } else {
                      completeConnection(element.id);
                    }
                  } else {
                    handleElementDragStart(e, element.id);
                  }
                }}
                onClick={(e) => {
                  if (connectingFrom && connectingFrom !== 'start') {
                    e.stopPropagation();
                  }
                }}
              >
                {/* ELEMENT CONTENT */}
                <div style={styles.elementContent}>
                  <input
                    type="text"
                    value={element.name}
                    placeholder={element.type === 'entity' ? 'Entity Name' : 
                                element.type === 'attribute' ? 'Attribute Name' : 
                                'Relationship Name'}
                    onChange={(e) => updateElementProperty(element.id, 'name', e.target.value)}
                    style={styles.elementInput}
                    onClick={(e) => e.stopPropagation()}
                  />
                  
                  {element.type === 'attribute' && (
                    <select
                      value={element.dataType}
                      onChange={(e) => updateElementProperty(element.id, 'dataType', e.target.value)}
                      style={styles.dataTypeSelect}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <option value="VARCHAR(255)">VARCHAR(255)</option>
                      <option value="INT">INT</option>
                      <option value="DATE">DATE</option>
                      <option value="DECIMAL(10,2)">DECIMAL</option>
                      <option value="TEXT">TEXT</option>
                      <option value="BOOLEAN">BOOLEAN</option>
                    </select>
                  )}

                  {/* ATTRIBUTE PROPERTIES */}
                  {element.type === 'attribute' && (
                    <div style={styles.attributeProperties}>
                      <label style={styles.propertyLabel}>
                        <input
                          type="checkbox"
                          checked={element.isPrimary}
                          onChange={(e) => updateElementProperty(element.id, 'isPrimary', e.target.checked)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        PK
                      </label>
                      <label style={styles.propertyLabel}>
                        <input
                          type="checkbox"
                          checked={element.isNotNull}
                          onChange={(e) => updateElementProperty(element.id, 'isNotNull', e.target.checked)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        NN
                      </label>
                      <label style={styles.propertyLabel}>
                        <input
                          type="checkbox"
                          checked={element.isUnique}
                          onChange={(e) => updateElementProperty(element.id, 'isUnique', e.target.checked)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        UQ
                      </label>
                    </div>
                  )}
                </div>

                {/* DELETE BUTTON */}
                <button
                  style={styles.deleteButton}
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteElement(element.id);
                  }}
                  onMouseEnter={(e) => e.target.style.opacity = '1'}
                  onMouseLeave={(e) => e.target.style.opacity = '0'}
                >
                  ×
                </button>

                {/* CONNECTION POINTS */}
                <div style={styles.connectionPoints}>
                  <div 
                    style={styles.connectionPoint}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startConnection(element.id);
                    }}
                    title="Connect from this element"
                  ></div>
                </div>
              </div>
            ))}

            {/* CONNECTION INSTRUCTIONS */}
            {erElements.length > 0 && (
              <div style={styles.connectionInstructions}>
                💡 Tip: {connectingFrom ? 
                  'Click on another element to create a connection' : 
                  'Click the dot on elements to connect them. Attributes connect to Entities.'}
              </div>
            )}
          </div>

          {/* GENERATED TABLE ON RIGHT SIDE */}
          <div style={styles.generatedTableSidebar}>
            {renderGeneratedTable()}
          </div>
        </div>


      </div>
    );
  };

  // Helper function to calculate connection points
  const getElementConnectionPoint = (element) => {
    const elementRect = {
      x: element.x,
      y: element.y,
      width: 150,
      height: element.type === 'relationship' ? 80 : 100
    };

    // Return center point of the element
    return {
      x: elementRect.x + elementRect.width / 2,
      y: elementRect.y + elementRect.height / 2
    };
  };

  // Execute the generated code
  const executeQuery = async () => {
    if (!generatedCode.trim()) {
      alert("No code generated! Please build a query first.");
      return;
    }

    setIsExecuting(true);
    setExecutionResult(null);
    setResultsPanelVisible(true);

    try {
      const code = generatedCode.trim();
      
      const endpoint = activeCategory === "SQL" 
        ? '/api/sql/execute'
        : '/api/nosql/execute';

      console.log('Executing query:', code);
      console.log('Endpoint:', endpoint);

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: code }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      
      if (result.success) {
        if (result.data && Array.isArray(result.data)) {
          setExecutionResult({
            ...result,
            displayData: result.data,
            displayMessage: `Query executed successfully. Returned ${result.data.length} row(s).`,
            showRawData: true
          });
        } else {
          setExecutionResult({
            ...result,
            displayData: null,
            displayMessage: result.message || 'Query executed successfully.',
            showRawData: false
          });
        }
      } else {
        setExecutionResult(result);
      }
    } catch (error) {
      console.error('Execution error:', error);
      setExecutionResult({
        success: false,
        error: error.message,
        type: activeCategory,
        message: 'Query execution failed. Please check your syntax and ensure the backend is running.'
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleCategorySelect = (category) => {
    setActiveCategory(category);
    setExecutionResult(null);
  };

  const toggleSidebar = () => {
    setSidebarVisible(!sidebarVisible);
  };

  const toggleCodePanel = () => {
    setCodePanelVisible(!codePanelVisible);
  };

  const toggleResultsPanel = () => {
    setResultsPanelVisible(!resultsPanelVisible);
  };

  const clearWorkspace = () => {
    if (workspaceRef.current) {
      workspaceRef.current.clear();
      setGeneratedCode("");
      setExecutionResult(null);
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode).then(() => {
      alert("Code copied to clipboard!");
    }).catch(err => {
      console.error('Failed to copy code:', err);
    });
  };

  const renderTable = (data) => {
    if (!data || data.length === 0) {
      return (
        <div style={styles.noData}>
          <div style={styles.noDataIcon}>📭</div>
          <div style={styles.noDataText}>No data returned</div>
        </div>
      );
    }
    
    const headers = Object.keys(data[0]);
    
    return (
      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead>
            <tr>
              {headers.map(header => (
                <th key={header} style={styles.th}>
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, index) => (
              <tr key={index} style={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
                {headers.map(header => (
                  <td key={header} style={styles.td}>
                    {typeof row[header] === 'object' 
                      ? JSON.stringify(row[header]) 
                      : String(row[header])
                    }
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderJSON = (data) => {
    if (!data || (Array.isArray(data) && data.length === 0)) {
      return (
        <div style={styles.noData}>
          <div style={styles.noDataIcon}>📭</div>
          <div style={styles.noDataText}>No documents found</div>
        </div>
      );
    }

    return (
      <div style={styles.jsonContainer}>
        <pre style={styles.jsonOutput}>
          {JSON.stringify(data, null, 2)}
        </pre>
      </div>
    );
  };

  const renderQueryOutput = (result) => {
    if (!result) return null;

    if (result.success && result.displayData && result.showRawData) {
      return (
        <div style={styles.resultsData}>
          <div style={styles.resultsSummary}>
            ✅ {result.displayMessage || result.message}
          </div>
          {activeCategory === "SQL" 
            ? renderTable(result.displayData)
            : renderJSON(result.displayData)
          }
        </div>
      );
    } else if (result.success) {
      return (
        <div style={styles.successResult}>
          <div style={styles.successIcon}>✅</div>
          <div style={styles.successText}>
            <strong>Query Executed Successfully</strong><br />
            {result.displayMessage || result.message}
            {result.affectedRows && (
              <div style={styles.affectedRows}>
                Affected rows: {result.affectedRows}
              </div>
            )}
          </div>
        </div>
      );
    } else {
      return (
        <div style={styles.errorResult}>
          <div style={styles.errorIcon}>❌</div>
          <div style={styles.errorText}>
            <strong>Error executing query:</strong><br />
            {result.error}
          </div>
        </div>
      );
    }
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <h1 style={styles.title}> SQL & NoSQL QUERY BUILDER</h1>
          <span style={styles.subtitle}>Advanced Visual Query Generator with Live Results</span>
        </div>
        <div style={styles.headerRight}>
          <button 
            style={styles.menuBtn}
            onClick={toggleSidebar}
          >
            {sidebarVisible ? "➖ Hide Menu" : "➕ Show Menu"}
          </button>
        </div>
      </div>

      <div style={styles.mainContent}>
        {/* Sidebar Navigation */}
        {sidebarVisible && (
          <div style={styles.sidebar}>
            <div style={styles.sidebarSection}>
              <h3 style={styles.sidebarTitle}> DATABASE TYPES</h3>
              <div style={styles.categoryList}>
                {[
                  { name: "SQL", icon: "🗄️", desc: "Structured Queries" },
                  { name: "NoSQL", icon: "📄", desc: "Document Queries" }
                ].map(category => (
                  <div
                    key={category.name}
                    style={{
                      ...styles.categoryItem,
                      ...(activeCategory === category.name ? styles.activeCategory : {})
                    }}
                    onClick={() => handleCategorySelect(category.name)}
                  >
                    <div style={styles.categoryIcon}>{category.icon}</div>
                    <div style={styles.categoryText}>
                      <div style={styles.categoryName}>{category.name}</div>
                      <div style={styles.categoryDesc}>{category.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={styles.sidebarSection}>
              <h3 style={styles.sidebarTitle}> QUICK ACTIONS</h3>
              <div style={styles.actionList}>
                <button style={styles.actionBtn} onClick={clearWorkspace}>
                   Clear Workspace
                </button>
                <button style={styles.actionBtn} onClick={executeQuery} disabled={isExecuting}>
                  {isExecuting ? "⏳ Executing..." : " Execute Query"}
                </button>
                <button style={styles.actionBtn} onClick={copyCode}>
                   Copy Code
                </button>
                {/* SHOW CODE BUTTON RESTORED */}
                <button style={styles.actionBtn} onClick={toggleCodePanel}>
                  {codePanelVisible ? " Hide Code" : " Show Code"}
                </button>
                <button style={styles.actionBtn} onClick={toggleResultsPanel}>
                  {resultsPanelVisible ? " Hide Results" : " Show Results"}
                </button>
                <button style={styles.actionBtn} onClick={generateERDiagram}>
                  🧠 Generate ER Diagram
                </button>
                {/* NEW BUTTON FOR ER DIAGRAM WORKSPACE */}
                <button 
                  style={{...styles.actionBtn, backgroundColor: '#1e40af'}}
                  onClick={() => setErWorkspaceVisible(true)}
                >
                  🎨 ER Diagram Workspace
                </button>
                <button 
                  style={{
                    ...styles.actionBtn,
                    backgroundColor: chatbotVisible ? '#7e22ce' : '#1e40af'
                  }} 
                  onClick={() => setChatbotVisible(true)}
                >
                  🤖 Get Help
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Workspace Area */}
        <div style={{
          ...styles.workspaceArea,
          marginLeft: sidebarVisible ? '20px' : '20px',
          marginRight: '20px',
          flex: 1
        }}>
          <div style={styles.workspaceHeader}>
            <div style={styles.workspaceTitleSection}>
              <h2 style={styles.workspaceTitle}>
                {activeCategory === "SQL" ? " SQL Query Builder" : " NoSQL Query Builder"}
              </h2>
              <div style={styles.workspaceInfo}>
                 Drag blocks from the <strong>left toolbox</strong> to build queries
                {!sidebarVisible && (
                  <span style={styles.menuHint}>
                    • <button 
                        style={styles.textBtn} 
                        onClick={toggleSidebar}
                      >
                        Show Menu
                      </button> to change database type
                  </span>
                )}
              </div>
            </div>
            {!sidebarVisible && (
              <div style={styles.quickActions}>
                <button style={styles.quickBtn} onClick={clearWorkspace}>
                   Clear
                </button>
                <button style={styles.quickBtn} onClick={executeQuery} disabled={isExecuting}>
                  {isExecuting ? "⏳" : "▶️"} Execute
                </button>
                <button style={styles.quickBtn} onClick={copyCode}>
                   Copy
                </button>
                {/* SHOW CODE BUTTON RESTORED IN QUICK ACTIONS */}
                <button style={styles.quickBtn} onClick={toggleCodePanel}>
                  {codePanelVisible ? " Code" : " Code"}
                </button>
                <button style={styles.quickBtn} onClick={toggleResultsPanel}>
                  {resultsPanelVisible ? " Results" : " Results"}
                </button>
              </div>
            )}
          </div>
          
          {/* Blockly Workspace - Fixed for visibility */}
          <div 
            ref={blocklyDiv} 
            style={styles.blocklyDiv}
          />
        </div>

        {/* Right Panel - Now Collapsible */}
        {(codePanelVisible || resultsPanelVisible) && (
          <div style={styles.rightPanel}>
            {/* Code Output Panel */}
            {codePanelVisible && (
              <div style={styles.codePanel}>
                <div style={styles.codeHeader}>
                  <h3 style={styles.codeTitle}>📜 GENERATED CODE</h3>
                  <div style={styles.codeActions}>
                    <button style={styles.smallBtn} onClick={copyCode}>
                      Copy
                    </button>
                    <button style={styles.smallBtn} onClick={executeQuery} disabled={isExecuting}>
                      {isExecuting ? "Executing..." : "Execute"}
                    </button>
                    <button style={styles.smallBtn} onClick={toggleCodePanel}>
                      ✕
                    </button>
                  </div>
                </div>
                <pre style={styles.codeOutput}>
                  {generatedCode || `// Welcome to SQL/NoSQL Query Builder!\n// 👇 Drag blocks from the LEFT TOOLBOX to start building queries\n// 🎯 Edit the text fields in each block\n// 💡 See your code appear here automatically`}
                </pre>
              </div>
            )}

            {/* Execution Results Panel */}
            {resultsPanelVisible && (
              <div style={styles.resultsPanel}>
                <div style={styles.resultsHeader}>
                  <h3 style={styles.resultsTitle}> EXECUTION RESULTS</h3>
                  <div style={styles.resultsHeaderActions}>
                    {executionResult && (
                      <div style={styles.resultsInfo}>
                        <span style={{
                          ...styles.resultCount,
                          backgroundColor: executionResult.success ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)',
                          color: executionResult.success ? '#16a34a' : '#dc2626'
                        }}>
                          {executionResult.success ? 
                            (executionResult.displayData ? `${executionResult.displayData.length} records` : 'Success') 
                            : 'Error'
                          }
                        </span>
                      </div>
                    )}
                    <button style={styles.smallBtn} onClick={toggleResultsPanel}>
                      ✕
                    </button>
                  </div>
                </div>
                <div style={styles.resultsContent}>
                  {isExecuting ? (
                    <div style={styles.loadingResults}>
                      <div style={styles.loadingSpinner}></div>
                      <div style={styles.loadingText}>Executing query...</div>
                    </div>
                  ) : !executionResult ? (
                    <div style={styles.noResults}>
                      <div style={styles.noResultsIcon}>📋</div>
                      <div style={styles.noResultsText}>
                        No results yet. Build a query and click "Execute" to see the output.
                      </div>
                    </div>
                  ) : (
                    renderQueryOutput(executionResult)
                  )}
                </div>
              </div>
            )}
          </div>
        )}

      {/* CHATGPT-STYLE CHATBOT */}
      {chatbotVisible && (
        <>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: 999
          }} onClick={() => setChatbotVisible(false)} />
          
          <div style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '500px',
            height: '700px',
            backgroundColor: '#0f172a',
            borderRadius: '16px',
            boxShadow: '0 20px 60px rgba(0,0,0,0.8)',
            border: '1px solid #334155',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 1000,
            overflow: 'hidden'
          }}>
            {/* Header */}
            <div style={{
              padding: '20px 24px',
              background: 'linear-gradient(135deg, #1e40af 0%, #2563eb 100%)',
              color: 'white',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #334155'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  backgroundColor: 'rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '16px'
                }}>
                  🤖
                </div>
                <div>
                  <h3 style={{ margin: 0, fontSize: '18px', fontWeight: '600' }}>Query Assistant</h3>
                  <div style={{ fontSize: '12px', opacity: 0.9, marginTop: '2px' }}>
                    I can help with SQL & NoSQL queries
                  </div>
                </div>
              </div>
              <button 
                style={{
                  background: 'rgba(255,255,255,0.15)',
                  border: 'none',
                  color: 'white',
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = 'rgba(255,255,255,0.25)'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'rgba(255,255,255,0.15)'}
                onClick={() => setChatbotVisible(false)}
              >
                ✕
              </button>
            </div>
            
            {/* Chat Messages Area */}
            <div style={{
              flex: 1,
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '16px',
              backgroundColor: '#0f172a',
              overflowY: 'auto'
            }} id="chat-messages">
              {/* Welcome Message */}
              <div style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start'
              }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  backgroundColor: '#1e40af',
                  borderRadius: '6px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '14px',
                  flexShrink: 0
                }}>
                  🤖
                </div>
                <div style={{
                  padding: '16px',
                  backgroundColor: '#1e293b',
                  borderRadius: '12px',
                  border: '1px solid #334155',
                  flex: 1
                }}>
                  <div style={{ fontSize: '14px', color: 'white', lineHeight: '1.5' }}>
                    👋 Hello! I'm your SQL/NoSQL assistant. I can help you with database queries, explain blocks, or suggest best practices. What would you like to know?
                  </div>
                </div>
              </div>

              {/* Sample User Message */}
              <div style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start',
                justifyContent: 'flex-end'
              }}>
                <div style={{
                  padding: '16px',
                  backgroundColor: '#1e40af',
                  borderRadius: '12px',
                  border: '1px solid #2563eb',
                  maxWidth: '80%'
                }}>
                  <div style={{ fontSize: '14px', color: 'white', lineHeight: '1.5' }}>
                    How do I create a SELECT query?
                  </div>
                </div>
                <div style={{
                  width: '32px',
                  height: '32px',
                  backgroundColor: '#334155',
                  borderRadius: '6px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '14px',
                  flexShrink: 0
                }}>
                  👤
                </div>
              </div>

              {/* Sample Bot Response */}
              <div style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-start'
              }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  backgroundColor: '#1e40af',
                  borderRadius: '6px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '14px',
                  flexShrink: 0
                }}>
                  🤖
                </div>
                <div style={{
                  padding: '16px',
                  backgroundColor: '#1e293b',
                  borderRadius: '12px',
                  border: '1px solid #334155',
                  flex: 1
                }}>
                  <div style={{ fontSize: '14px', color: 'white', lineHeight: '1.5', whiteSpace: 'pre-wrap' }}>
                    To create a SELECT query:\n\n1. Go to <strong>DML Commands</strong> category\n2. Drag the <strong>SELECT</strong> block to workspace\n3. Edit the fields:\n   • <strong>COLUMNS</strong>: * (all) or specific columns\n   • <strong>TABLE</strong>: Your table name\n   • <strong>CONDITION</strong>: WHERE clause (e.g., id = 1)\n\nTry it out! The generated code will appear in the right panel. 🚀
                  </div>
                </div>
              </div>

              {/* Space for new messages */}
              <div style={{ height: '20px' }}></div>
            </div>

            {/* Quick Action Buttons */}
            <div style={{
              padding: '16px 20px',
              borderTop: '1px solid #334155',
              backgroundColor: '#1e293b',
              display: 'flex',
              flexWrap: 'wrap',
              gap: '8px'
            }}>
              {["Hiii",
                "How to use WHERE?",
                "JOIN examples", 
                "NoSQL vs SQL",
                "Insert data",
                "Update records",
                "Aggregate functions"
              ].map((label, index) => (
                <button
                  key={index}
                  style={{
                    padding: '8px 12px',
                    backgroundColor: 'rgba(30, 64, 175, 0.2)',
                    border: '1px solid rgba(30, 64, 175, 0.3)',
                    borderRadius: '20px',
                    color: '#60a5fa',
                    fontSize: '12px',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    whiteSpace: 'nowrap'
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.backgroundColor = 'rgba(30, 64, 175, 0.4)';
                    e.target.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.backgroundColor = 'rgba(30, 64, 175, 0.2)';
                    e.target.style.transform = 'translateY(0px)';
                  }}
                  onClick={() => {
                    // Add user message
                    const userMessage = document.createElement('div');
                    userMessage.innerHTML = `
                      <div style="display: flex; gap: 12px; align-items: flex-start; justify-content: flex-end; margin-bottom: 16px;">
                        <div style="padding: 16px; background-color: #1e40af; border-radius: 12px; border: 1px solid #2563eb; max-width: 80%;">
                          <div style="font-size: 14px; color: white; line-height: 1.5;">${label}</div>
                        </div>
                        <div style="width: 32px; height: 32px; background-color: #334155; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">👤</div>
                      </div>
                    `;
                    
                    document.getElementById('chat-messages').appendChild(userMessage);

                    // Add bot response after delay
                    setTimeout(() => {
                      const responses = {
                        "Hiii":"Hello!! What can i help you ?",
                        "How to use WHERE?": "Use WHERE clause in SELECT, UPDATE, DELETE blocks to filter records:\n\n• WHERE id = 1\n• WHERE age > 18\n• WHERE name LIKE 'John%'\n\nAlways test your conditions!",
                        "JOIN examples": "JOIN Operations:\n\n• INNER JOIN: Matching rows from both tables\n• LEFT JOIN: All left table + matching right\n• RIGHT JOIN: All right table + matching left\n\nFind these in JOIN Operations category!",
                        "NoSQL vs SQL": "SQL: Structured tables, relationships, complex queries\nNoSQL: Flexible documents, scalability, fast reads\n\nUse SQL for financial data, NoSQL for real-time apps!",
                        "Insert data": "SQL: INSERT INTO table VALUES (val1, val2)\nNoSQL: db.collection.insert({field: value})\n\nUse INSERT block for SQL or insert() for NoSQL!",
                        "Update records": "SQL: UPDATE table SET column=value WHERE condition\nNoSQL: db.collection.update(query, update)\n\nAlways use WHERE to target specific records!",
                        "Aggregate functions": "Aggregate Functions:\n• COUNT() - count rows\n• SUM() - sum values\n• AVG() - average\n• MAX/MIN() - find extremes\n\nUse with GROUP BY for summaries!"
                      };

                      const botResponse = document.createElement('div');
                      botResponse.innerHTML = `
                        <div style="display: flex; gap: 12px; align-items: flex-start; margin-bottom: 16px;">
                          <div style="width: 32px; height: 32px; background-color: #1e40af; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">🤖</div>
                          <div style="padding: 16px; background-color: #1e293b; border-radius: 12px; border: 1px solid #334155; flex: 1;">
                            <div style="font-size: 14px; color: white; line-height: '1.5'; white-space: pre-wrap;">${responses[label] || "I can help with that! Try building it in the workspace."}</div>
                          </div>
                        </div>
                      `;
                      
                      document.getElementById('chat-messages').appendChild(botResponse);
                      document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;
                    }, 1000);
                  }}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Chat Input */}
            <div style={{
              padding: '16px 20px',
              borderTop: '1px solid #334155',
              backgroundColor: '#1e293b'
            }}>
              <div style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'flex-end'
              }}>
                <textarea
                  style={{
                    flex: 1,
                    padding: '12px 16px',
                    borderRadius: '12px',
                    border: '1px solid #334155',
                    backgroundColor: '#0f172a',
                    color: 'white',
                    fontSize: '14px',
                    resize: 'none',
                    outline: 'none',
                    fontFamily: 'inherit',
                    minHeight: '60px',
                    maxHeight: '120px'
                  }}
                  placeholder="Message Query Assistant..."
                  rows="2"
                />
                <button 
                  style={{
                    padding: '12px 20px',
                    backgroundColor: '#1e40af',
                    border: 'none',
                    borderRadius: '12px',
                    color: 'white',
                    fontSize: '14px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    height: 'fit-content'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#2563eb'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#1e40af'}
                  onClick={() => {
                    const input = document.querySelector('textarea');
                    if (input.value.trim()) {
                      // Add user message
                      const userMessage = document.createElement('div');
                      userMessage.innerHTML = `
                        <div style="display: flex; gap: 12px; align-items: flex-start; justify-content: flex-end; margin-bottom: 16px;">
                          <div style="padding: 16px; background-color: #1e40af; border-radius: 12px; border: 1px solid #2563eb; max-width: 80%;">
                            <div style="font-size: 14px; color: white; line-height: 1.5;">${input.value}</div>
                          </div>
                          <div style="width: 32px; height: 32px; background-color: #334155; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">👤</div>
                        </div>
                      `;
                      
                      document.getElementById('chat-messages').appendChild(userMessage);
                      input.value = '';

                      // Add typing indicator
                      const typing = document.createElement('div');
                      typing.innerHTML = `
                        <div style="display: flex; gap: 12px; align-items: flex-start; margin-bottom: 16px;">
                          <div style="width: 32px; height: 32px; background-color: '#1e40af'; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">🤖</div>
                          <div style="padding: 16px; background-color: '#1e293b'; border-radius: '12px'; border: 1px solid #334155; flex: 1;">
                            <div style="font-size: 14px; color: '#94a3b8'; font-style: italic;">Typing...</div>
                          </div>
                        </div>
                      `;
                      document.getElementById('chat-messages').appendChild(typing);
                      document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;

                      // Simulate bot response
                      setTimeout(() => {
                        typing.remove();
                        const botResponse = document.createElement('div');
                        botResponse.innerHTML = `
                          <div style="display: flex; gap: 12px; align-items: flex-start; margin-bottom: 16px;">
                            <div style="width: 32px; height: 32px; background-color: '#1e40af'; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">🤖</div>
                            <div style="padding: 16px; background-color: '#1e293b'; border-radius: 12px; border: 1px solid #334155; flex: 1;">
                              <div style="font-size: 14px; color: white; line-height: 1.5; white-space: pre-wrap;">I understand your question! For specific SQL/NoSQL help, try using the quick action buttons above or build your query in the main workspace. I'm here to guide you through the process! 🚀</div>
                            </div>
                          </div>
                        `;
                        document.getElementById('chat-messages').appendChild(botResponse);
                        document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;
                      }, 1500);
                    }
                  }}
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* MIND MAP ER DIAGRAM MODAL */}
      {erDiagramVisible && (
        <>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: 999
          }} onClick={() => setErDiagramVisible(false)} />
          
          <div style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '95%',
            height: '85%',
            backgroundColor: '#0f172a',
            borderRadius: '16px',
            boxShadow: '0 20px 60px rgba(0,0,0,0.8)',
            border: '1px solid #334155',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 1000,
            overflow: 'hidden'
          }}>
            {/* Header */}
            <div style={{
              padding: '20px 24px',
              background: 'linear-gradient(135deg, #7e22ce 0%, #a855f7 100%)',
              color: 'white',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #334155'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  backgroundColor: 'rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '16px'
                }}>
                  🧠
                </div>
                <div>
                  <h3 style={{ margin: 0, fontSize: '18px', fontWeight: '600' }}>Database ER Diagram</h3>
                  <div style={{ fontSize: '12px', opacity: 0.9, marginTop: '2px' }}>
                    Entity-Relationship diagram of your database structure
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button 
                  style={{
                    padding: '8px 16px',
                    backgroundColor: '#1e40af',
                    border: 'none',
                    borderRadius: '8px',
                    color: 'white',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: '600',
                    transition: 'all 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#2563eb'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#1e40af'}
                  onClick={generateERDiagram}
                >
                  🔄 Generate
                </button>
                <button 
                  style={{
                    padding: '8px 16px',
                    backgroundColor: '#dc2626',
                    border: 'none',
                    borderRadius: '8px',
                    color: 'white',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: '600',
                    transition: 'all 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = '#ef4444'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = '#dc2626'}
                  onClick={clearDiagram}
                >
                  🗑️ Clear
                </button>
                <button 
                  style={{
                    background: 'rgba(255,255,255,0.15)',
                    border: 'none',
                    color: 'white',
                    width: '32px',
                    height: '32px',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    fontSize: '16px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.target.style.backgroundColor = 'rgba(255,255,255,0.25)'}
                  onMouseLeave={(e) => e.target.style.backgroundColor = 'rgba(255,255,255,0.15)'}
                  onClick={() => setErDiagramVisible(false)}
                >
                  ✕
                </button>
              </div>
            </div>
            
            {/* ER Diagram Content Area - Full screen */}
            <div style={{
              flex: 1,
              backgroundColor: '#0f172a',
              overflow: 'auto',
              position: 'relative'
            }}>
              {renderMindMapERDiagram()}
            </div>
          </div>
        </>
      )}

      {/* NEW ER DIAGRAM WORKSPACE MODAL */}
      {erWorkspaceVisible && (
        <>
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: 999
          }} onClick={() => setErWorkspaceVisible(false)} />
          
          <div style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '95%',
            height: '85%',
            backgroundColor: '#0f172a',
            borderRadius: '16px',
            boxShadow: '0 20px 60px rgba(0,0,0,0.8)',
            border: '1px solid #334155',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 1000,
            overflow: 'hidden'
          }}>
            {/* Header */}
            <div style={{
              padding: '20px 24px',
              background: 'linear-gradient(135deg, #7e22ce 0%, #a855f7 100%)',
              color: 'white',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              borderBottom: '1px solid #334155'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  backgroundColor: 'rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '16px'
                }}>
                  🎨
                </div>
                <div>
                  <h3 style={{ margin: 0, fontSize: '18px', fontWeight: '600' }}>ER Diagram Workspace</h3>
                  <div style={{ fontSize: '12px', opacity: 0.9, marginTop: '2px' }}>
                    Drag and drop ER symbols to design your database
                  </div>
                </div>
              </div>
              <button 
                style={{
                  background: 'rgba(255,255,255,0.15)',
                  border: 'none',
                  color: 'white',
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontSize: '16px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = 'rgba(255,255,255,0.25)'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'rgba(255,255,255,0.15)'}
                onClick={() => setErWorkspaceVisible(false)}
              >
                ✕
              </button>
            </div>
            
            {/* ER Workspace Content */}
            <div style={{
              flex: 1,
              backgroundColor: '#0f172a',
              overflow: 'hidden'
            }}>
              {renderERWorkspace()}
            </div>
          </div>
        </>
      )}
      
      </div>
    </div>
  );
}

// Updated styles with proper ER diagram symbols and table on right side
const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#0f172a',
    fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif',
    color: '#131518ff'
  },
  header: {
    background: 'linear-gradient(135deg, #1e40af 0%, #2563eb 100%)',
    color: 'white',
    padding: '15px 30px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    boxShadow: '0 2px 20px rgba(30, 64, 175, 0.3)',
    borderBottom: '1px solid #334155'
  },
  headerLeft: {
    display: 'flex',
    flexDirection: 'column'
  },
  title: {
    margin: 0,
    fontSize: '24px',
    fontWeight: '700',
    color: 'white'
  },
  subtitle: {
    margin: 0,
    fontSize: '14px',
    opacity: 0.9,
    marginTop: '5px',
    color: '#a8c9f4ff'
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '15px'
  },
  menuBtn: {
    background: 'rgba(255,255,255,0.15)',
    border: '1px solid rgba(255,255,255,0.3)',
    color: 'white',
    padding: '8px 15px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: '600',
    transition: 'all 0.2s ease'
  },
  mainContent: {
    display: 'flex',
    flex: 1,
    overflow: 'hidden',
    backgroundColor: '#0f172a'
  },
  sidebar: {
    width: '280px',
    backgroundColor: '#1e293b',
    padding: '20px',
    boxShadow: '2px 0 20px rgba(0,0,0,0.3)',
    display: 'flex',
    flexDirection: 'column',
    gap: '25px',
    borderRight: '1px solid #334155'
  },
  sidebarSection: {
    display: 'flex',
    flexDirection: 'column'
  },
  sidebarTitle: {
    fontSize: '14px',
    fontWeight: '700',
    color: '#60a5fa',
    margin: '0 0 15px 0',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },
  categoryList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  },
  categoryItem: {
    padding: '12px',
    backgroundColor: '#334155',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    border: '2px solid transparent',
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  },
  activeCategory: {
    backgroundColor: '#1e40af',
    color: 'white',
    borderColor: '#3b82f6',
    transform: 'translateX(5px)'
  },
  categoryIcon: {
    fontSize: '18px'
  },
  categoryText: {
    display: 'flex',
    flexDirection: 'column'
  },
  categoryName: {
    fontWeight: '600',
    fontSize: '14px'
  },
  categoryDesc: {
    fontSize: '11px',
    opacity: 0.8,
    marginTop: '2px'
  },
  actionList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  actionBtn: {
    padding: '12px',
    backgroundColor: '#1e40af',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: '600',
    transition: 'all 0.2s',
    textAlign: 'left'
  },
  workspaceArea: {
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: '#1e293b',
    borderRadius: '12px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
    overflow: 'hidden',
    transition: 'all 0.3s ease',
    margin: '15px',
    border: '1px solid #334155'
  },
  workspaceHeader: {
    padding: '15px 20px',
    borderBottom: '1px solid #334155',
    backgroundColor: '#1e293b',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  workspaceTitleSection: {
    display: 'flex',
    flexDirection: 'column'
  },
  workspaceTitle: {
    margin: '0 0 5px 0',
    color: '#b7cfe6ff',
    fontSize: '18px',
    fontWeight: '600'
  },
  workspaceInfo: {
    color: '#94a9c8ff',
    fontSize: '13px'
  },
  menuHint: {
    marginLeft: '8px',
    fontSize: '11px'
  },
  textBtn: {
    background: 'none',
    border: 'none',
    color: '#60a5fa',
    cursor: 'pointer',
    textDecoration: 'underline',
    fontSize: '11px'
  },
  quickActions: {
    display: 'flex',
    gap: '8px'
  },
  quickBtn: {
    padding: '6px 12px',
    backgroundColor: '#1e40af',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '11px',
    fontWeight: '600',
    transition: 'all 0.2s'
  },
  blocklyDiv: {
    flex: 1,
    minHeight: '400px',
    backgroundColor: '#1e293b',
    width: '100%'
  },
  rightPanel: {
    width: '500px',
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
    margin: '15px 15px 15px 0'
  },
  codePanel: {
    flex: 1,
    backgroundColor: '#1e293b',
    borderRadius: '12px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    border: '1px solid #334155'
  },
  codeHeader: {
    padding: '15px 20px',
    borderBottom: '1px solid #334155',
    backgroundColor: '#1e40af',
    color: 'white',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  codeTitle: {
    margin: 0,
    fontSize: '14px',
    fontWeight: '600'
  },
  codeActions: {
    display: 'flex',
    gap: '6px'
  },
  smallBtn: {
    background: 'rgba(255,255,255,0.15)',
    border: '1px solid rgba(255,255,255,0.2)',
    color: 'white',
    padding: '4px 10px',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '11px',
    fontWeight: '500',
    transition: 'all 0.2s'
  },
  codeOutput: {
    flex: 1,
    margin: 0,
    padding: '20px',
    backgroundColor: '#0f172a',
    color: '#e2e8f0',
    fontSize: '13px',
    fontFamily: '"Fira Code", "Monaco", "Consolas", monospace',
    overflow: 'auto',
    whiteSpace: 'pre-wrap',
    lineHeight: '1.4'
  },
  resultsPanel: {
    flex: 1,
    backgroundColor: '#1e293b',
    borderRadius: '12px',
    boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    border: '1px solid #334155'
  },
  resultsHeader: {
    padding: '15px 20px',
    borderBottom: '1px solid #334155',
    backgroundColor: '#1e40af',
    color: 'white',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  resultsTitle: {
    margin: 0,
    fontSize: '14px',
    fontWeight: '600'
  },
  resultsHeaderActions: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  },
  resultsInfo: {
    fontSize: '12px',
    opacity: 0.9
  },
  resultCount: {
    padding: '2px 8px',
    borderRadius: '10px',
    fontSize: '11px',
    fontWeight: '600'
  },
  resultsContent: {
    flex: 1,
    padding: '0',
    overflow: 'auto',
    backgroundColor: '#0f172a'
  },
  loadingResults: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    color: '#94a3b8',
    textAlign: 'center',
    padding: '40px 20px'
  },
  loadingSpinner: {
    width: '32px',
    height: '32px',
    border: '3px solid #334155',
    borderTop: '3px solid #60a5fa',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
    marginBottom: '15px'
  },
  loadingText: {
    fontSize: '14px'
  },
  noResults: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    color: '#94a3b8',
    textAlign: 'center',
    padding: '40px 20px'
  },
  noResultsIcon: {
    fontSize: '48px',
    marginBottom: '15px',
    opacity: 0.5
  },
  noResultsText: {
    fontSize: '14px',
    lineHeight: '1.5'
  },
  resultsData: {
    padding: '15px'
  },
  resultsSummary: {
    backgroundColor: '#064e3b',
    color: '#34d399',
    padding: '10px 15px',
    borderRadius: '8px',
    marginBottom: '15px',
    fontSize: '13px',
    border: '1px solid #065f46',
    fontWeight: '500'
  },
  successResult: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '15px',
    padding: '20px',
    backgroundColor: '#064e3b',
    color: '#34d399',
    borderRadius: '8px',
    margin: '15px',
    border: '1px solid #065f46'
  },
  successIcon: {
    fontSize: '24px',
    flexShrink: 0
  },
  successText: {
    fontSize: '13px',
    lineHeight: '1.4'
  },
  affectedRows: {
    marginTop: '8px',
    padding: '4px 8px',
    backgroundColor: '#065f46',
    borderRadius: '4px',
    fontSize: '12px'
  },
  errorResult: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '15px',
    padding: '20px',
    backgroundColor: '#7f1d1d',
    color: '#f87171',
    borderRadius: '8px',
    margin: '15px',
    border: '1px solid #991b1b'
  },
  errorIcon: {
    fontSize: '24px',
    flexShrink: 0
  },
  errorText: {
    fontSize: '13px',
    lineHeight: '1.4'
  },
  tableContainer: {
    overflow: 'auto',
    maxHeight: '300px',
    border: '1px solid #334155',
    borderRadius: '8px'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '12px',
    backgroundColor: '#1e293b'
  },
  th: {
    backgroundColor: '#1e40af',
    color: 'white',
    border: '1px solid #1e40af',
    padding: '10px 12px',
    textAlign: 'left',
    fontWeight: '600',
    position: 'sticky',
    top: 0
  },
  td: {
    border: '1px solid #334155',
    padding: '8px 12px',
    color: '#e2e8f0'
  },
  evenRow: {
    backgroundColor: '#1e293b'
  },
  oddRow: {
    backgroundColor: '#0f172a'
  },
  jsonContainer: {
    maxHeight: '300px',
    overflow: 'auto'
  },
  jsonOutput: {
    backgroundColor: '#1e293b',
    padding: '15px',
    borderRadius: '8px',
    fontSize: '12px',
    fontFamily: '"Fira Code", monospace',
    overflow: 'auto',
    border: '1px solid #334155',
    margin: 0,
    color: '#e2e8f0'
  },
  noData: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '150px',
    color: '#94a3b8',
    textAlign: 'center'
  },
  noDataIcon: {
    fontSize: '36px',
    marginBottom: '10px',
    opacity: 0.5
  },
  noDataText: {
    fontSize: '14px'
  },
  // UPDATED ER DIAGRAM STYLES - FIXED FIELD CONNECTIONS
  erDiagramContainer: {
    width: '100%',
    height: '100%',
    position: 'relative',
    overflow: 'auto',
    backgroundColor: '#0f172a'
  },
  erDiagram: {
    width: '100%',
    height: '100%',
    position: 'relative',
    minWidth: '1000px',
    minHeight: '800px',
    background: 'radial-gradient(circle at center, #1e293b 0%, #0f172a 100%)'
  },
  
  // Center Database Node - DIAMOND SHAPE
  centerNode: {
    position: 'absolute',
    top: '350px',
    left: '400px',
    transform: 'translate(-50%, -50%)',
    zIndex: 30
  },
  databaseDiamond: {
    width: '120px',
    height: '120px',
    backgroundColor: '#1e40af',
    background: 'linear-gradient(135deg, #1e40af 0%, #2563eb 100%)',
    border: '3px solid #3b82f6',
    transform: 'rotate(45deg)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 8px 32px rgba(30, 64, 175, 0.6)'
  },
  databaseDiamondContent: {
    transform: 'rotate(-45deg)',
    textAlign: 'center',
    color: 'white'
  },
  databaseIcon: {
    fontSize: '24px',
    marginBottom: '8px',
    filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))'
  },
  databaseText: {
    fontWeight: 'bold',
    fontSize: '14px',
    textShadow: '0 1px 2px rgba(0,0,0,0.5)'
  },

  // Database to Table Connections
  databaseConnections: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    pointerEvents: 'none',
    zIndex: 5
  },

  // Table Nodes - FIXED: Proper table structure
  tableNode: {
    zIndex: 20,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  },
  tableNameBox: {
    backgroundColor: '#7e22ce',
    background: 'linear-gradient(135deg, #7e22ce 0%, #a855f7 100%)',
    border: '2px solid #c084fc',
    borderRadius: '8px',
    padding: '12px 20px',
    color: 'white',
    textAlign: 'center',
    boxShadow: '0 6px 20px rgba(126, 34, 206, 0.4)',
    minWidth: '120px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    zIndex: 25
  },
  tableIcon: {
    fontSize: '16px'
  },
  tableNameText: {
    fontWeight: '600',
    fontSize: '14px',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },

  // FIELDS CONTAINER - FIXED: Fields are now properly grouped under table
  fieldsContainer: {
    marginTop: '10px',
    display: 'flex',
    flexDirection: 'row',
    gap: '5px',
    zIndex: 20
  },
  fieldRow: {
    display: 'flex',
    justifyContent: 'row'
  },

  // Field Boxes - FIXED: Proper positioning
  fieldBox: {
    backgroundColor: '#059669',
    background: 'linear-gradient(135deg, #059669 0%, #10b981 100%)',
    border: '2px solid #34d399',
    borderRadius: '6px',
    padding: '6px 12px 12px 12px ',
    color: 'white',
    textAlign: 'center',
    boxShadow: '0 4px 15px rgba(5, 150, 105, 0.3)',
    minWidth: '90px',
    zIndex: 25
  },
  fieldHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '4px'
  },
  fieldName: {
    fontWeight: '600',
    fontSize: '11px',
    flex: 1
  },
  fieldIcons: {
    display: 'flex',
    gap: '2px'
  },
  pkIcon: {
    fontSize: '10px'
  },
  fkIcon: {
    fontSize: '10px'
  },
  fieldType: {
    fontSize: '9px',
    opacity: 0.9,
    fontStyle: 'italic'
  },

  // Table to Field Connections - FIXED: Proper vertical connections
  tableConnections: {
    position: 'absolute',
    top: '30px', // Start from bottom of table name
    left: '50%',
    transform: 'translateX(-50%)',
    height: '200px',
    width: '2px',
    pointerEvents: 'none',
    zIndex: 15
  },

  // Relationship Connections
  relationshipConnections: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    pointerEvents: 'none',
    zIndex: 10
  },

  // Legend Styles
  legend: {
    position: 'absolute',
    bottom: '20px',
    right: '20px',
    backgroundColor: 'rgba(30, 41, 59, 0.95)',
    border: '1px solid #334155',
    borderRadius: '12px',
    padding: '16px',
    backdropFilter: 'blur(10px)',
    boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
    zIndex: 40
  },
  legendTitle: {
    color: '#e2e8f0',
    fontSize: '14px',
    fontWeight: '600',
    marginBottom: '12px',
    textAlign: 'center',
    borderBottom: '1px solid #334155',
    paddingBottom: '8px'
  },
  legendItems: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  legendItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    fontSize: '12px',
    color: '#cbd5e1'
  },
  legendColor: {
    width: '16px',
    height: '4px',
    borderRadius: '2px',
    border: '1px solid rgba(255,255,255,0.2)'
  },
  legendIcon: {
    fontSize: '14px',
    width: '16px',
    textAlign: 'center'
  },

  erWorkspaceContainer: {
    display: 'flex',
    height: '100%',
    backgroundColor: '#0f172a'
  },
  workspaceAndTable: {
  display: 'flex',
  flex: 1,
  overflow: 'hidden'
},
  erToolbar: {
    width: '250px',
    backgroundColor: '#1e293b',
    padding: '20px',
    borderRight: '1px solid #334155',
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  erToolbarTitle: {
    color: '#e2e8f0',
    fontSize: '16px',
    fontWeight: '600',
    margin: 0
  },
  erTools: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  toolCategory: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  },
  toolCategoryTitle: {
    color: '#94a3b8',
    fontSize: '12px',
    fontWeight: '600',
    textTransform: 'uppercase'
  },
  toolButtons: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  toolButton: {
    padding: '10px 12px',
    backgroundColor: '#374151',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: '500',
    transition: 'all 0.2s',
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  entitySymbol: {
    fontSize: '16px',
    fontWeight: 'bold'
  },
  attributeSymbol: {
    fontSize: '16px',
    fontWeight: 'bold'
  },
  relationshipSymbol: {
    fontSize: '16px',
    fontWeight: 'bold',
    transform: 'rotate(45deg)'
  },
  connectionHint: {
    fontSize: '11px',
    color: '#94a3b8',
    padding: '8px',
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    borderRadius: '4px',
    border: '1px solid rgba(59, 130, 246, 0.2)'
  },
  workspaceAndTable: {
    display: 'flex',
    flex: 1,
    overflow: 'hidden'
  },
  erWorkspace: {
    flex: 1,
    position: 'relative',
    backgroundColor: '#0f172a',
    overflow: 'auto'
  },
  workspaceGrid: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundImage: `
      linear-gradient(rgba(30, 41, 59, 0.3) 1px, transparent 1px),
      linear-gradient(90deg, rgba(30, 41, 59, 0.3) 1px, transparent 1px)
    `,
    backgroundSize: '20px 20px'
  },
  erConnections: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    pointerEvents: 'none',
    zIndex: 5
  },
  erElement: {
    position: 'absolute',
    width: '150px',
    minHeight: '80px',
    borderRadius: '8px',
    backgroundColor: '#1e293b',
    boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
    cursor: 'grab',
    zIndex: 10,
    transition: 'all 0.2s'
  },
  entityElement: {
    backgroundColor: '#1e1b4b',
    borderRadius: '0px' // Rectangle shape for entity
  },
  attributeElement: {
    backgroundColor: '#022c22',
    borderRadius: '50px' // Oval shape for attribute
  },
  relationshipElement: {
    backgroundColor: '#451a03',
    transform: 'rotate(45deg)', // Diamond shape for relationship
    width: '90px',
    height: '90px'
  },
  elementContent: {
    padding: '12px',
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    transform: 'rotate(0deg)' // Counter-rotate content for relationship
  },
  elementInput: {
    backgroundColor: 'transparent',
    border: 'none',
    color: 'white',
    fontSize: '12px',
    fontWeight: '600',
    outline: 'none',
    width: '100%',
    padding: '4px 0',
    borderBottom: '1px solid #374151',
    textAlign: 'center'
  },
  dataTypeSelect: {
    backgroundColor: '#374151',
    border: '1px solid #4b5563',
    color: 'white',
    fontSize: '10px',
    borderRadius: '4px',
    padding: '4px 6px',
    outline: 'none'
  },
  attributeProperties: {
    display: 'flex',
    gap: '8px',
    fontSize: '10px',
    justifyContent: 'center'
  },
  propertyLabel: {
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    color: '#d1d5db',
    cursor: 'pointer'
  },
  deleteButton: {
    position: 'absolute',
    top: '4px',
    right: '8px',
    background: 'rgba(239, 68, 68, 0.8)',
    border: 'none',
    color: 'white',
    width: '16px',
    height: '16px',
    borderRadius: '50%',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0,
    transition: 'opacity 0.2s',
    zIndex: 15
  },
  connectionPoints: {
    position: 'absolute',
    top: '50%',
    right: '-6px',
    transform: 'translateY(-50%)'
  },
  connectionPoint: {
    width: '12px',
    height: '12px',
    borderRadius: '50%',
    backgroundColor: '#3b82f6',
    cursor: 'pointer',
    border: '2px solid #1e293b',
    transition: 'all 0.2s'
  },
  connectionInstructions: {
    position: 'absolute',
    bottom: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: 'rgba(30, 41, 59, 0.9)',
    color: '#94a3b8',
    padding: '8px 16px',
    borderRadius: '20px',
    fontSize: '12px',
    border: '1px solid #374151'
  },
  generatedTableSidebar: {
    width: '420px',
    backgroundColor: '#1e293b',
    borderLeft: '1px solid #334155',
    padding: '20px',
    overflow: 'auto'
  },
  generatedTableContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  generatedTableTitle: {
    color: '#e2e8f0',
    fontSize: '16px',
    fontWeight: '600',
    margin: '0 0 10px 0',
    borderBottom: '1px solid #334155',
    paddingBottom: '8px'
  },
  tableCard: {
    backgroundColor: '#0f172a',
    borderRadius: '8px',
    border: '1px solid #334155',
    overflow: 'hidden'
  },
  tableHeader: {
    backgroundColor: '#1e40af',
    color: 'white',
    padding: '12px 15px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  tableName: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontWeight: '600',
    fontSize: '14px'
  },
  tableIcon: {
    fontSize: '14px'
  },
  tableType: {
    fontSize: '10px',
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: '2px 6px',
    borderRadius: '4px'
  },
  tableColumns: {
    padding: '0'
  },
  columnHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px 15px',
    backgroundColor: '#1e293b',
    color: '#94a3b8',
    fontSize: '11px',
    fontWeight: '600',
    borderBottom: '1px solid #334155'
  },
  columnRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px 15px',
    borderBottom: '1px solid #334155',
    fontSize: '11px',
    color: '#e2e8f0'
  },
  columnName: {
    fontWeight: '500',
    flex: 1
  },
  columnType: {
    color: '#60a5fa',
    width: '80px',
    textAlign: 'right'
  },
  columnConstraints: {
    width: '60px',
    textAlign: 'right',
    display: 'flex',
    gap: '4px',
    justifyContent: 'flex-end'
  },
  constraintPk: {
    backgroundColor: '#dc2626',
    color: 'white',
    fontSize: '8px',
    padding: '1px 4px',
    borderRadius: '3px',
    fontWeight: 'bold'
  },
  constraintNn: {
    backgroundColor: '#059669',
    color: 'white',
    fontSize: '8px',
    padding: '1px 4px',
    borderRadius: '3px',
    fontWeight: 'bold'
  },
  constraintUq: {
    backgroundColor: '#d97706',
    color: 'white',
    fontSize: '8px',
    padding: '1px 4px',
    borderRadius: '3px',
    fontWeight: 'bold'
  },
  noTable: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '200px',
    color: '#94a3b8',
    textAlign: 'center',
    padding: '20px'
  },
  noTableIcon: {
    fontSize: '36px',
    marginBottom: '10px',
    opacity: 0.5
  },
  noTableText: {
    fontSize: '12px',
    lineHeight: '1.4'
  },
  // CORRECTED STYLES FOR ER DIAGRAM
allConnections: {
  position: 'absolute',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  pointerEvents: 'none',
  zIndex: 10
},

tableBox: {
  backgroundColor: '#7e22ce',
  background: 'linear-gradient(135deg, #7e22ce 0%, #a855f7 100%)',
  border: '2px solid #c084fc',
  borderRadius: '8px',
  padding: '15px 20px',
  color: 'white',
  textAlign: 'center',
  boxShadow: '0 6px 20px rgba(126, 34, 206, 0.4)',
  minWidth: '120px',
  zIndex: 25
},

tableIcon: {
  fontSize: '16px',
  marginBottom: '5px'
},

tableName: {
  fontWeight: '600',
  fontSize: '14px',
  textTransform: 'uppercase'
},

attributeBox: {
  backgroundColor: '#059669',
  background: 'linear-gradient(135deg, #059669 0%, #10b981 100%)',
  border: '2px solid #34d399',
  borderRadius: '20px', // Oval shape
  padding: '10px 15px',
  color: 'white',
  textAlign: 'center',
  boxShadow: '0 4px 15px rgba(5, 150, 105, 0.3)',
  minWidth: '100px',
  zIndex: 20
},

attributeContent: {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  gap: '4px'
},

attributeName: {
  fontWeight: '600',
  fontSize: '12px'
},

attributeType: {
  fontSize: '10px',
  opacity: 0.9,
  fontStyle: 'italic'
},

attributeIcons: {
  display: 'flex',
  gap: '4px',
  marginTop: '2px'
},

pkIcon: {
  fontSize: '10px'
},

fkIcon: {
  fontSize: '10px'
},

centerNode: {
  position: 'absolute',
  top: '400px',
  left: '500px',
  transform: 'translate(-50%, -50%)',
  zIndex: 30
},

databaseDiamond: {
  width: '120px',
  height: '120px',
  backgroundColor: '#1e40af',
  background: 'linear-gradient(135deg, #1e40af 0%, #2563eb 100%)',
  border: '3px solid #3b82f6',
  transform: 'rotate(45deg)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  boxShadow: '0 8px 32px rgba(30, 64, 175, 0.6)'
},

databaseDiamondContent: {
  transform: 'rotate(-45deg)',
  textAlign: 'center',
  color: 'white'
},

databaseIcon: {
  fontSize: '24px',
  marginBottom: '8px'
},

databaseText: {
  fontWeight: 'bold',
  fontSize: '14px'
},

erDiagramContainer: {
  width: '100%',
  height: '100%',
  position: 'relative',
  overflow: 'auto',
  backgroundColor: '#0f172a'
},

erDiagram: {
  width: '1000px',
  height: '800px',
  position: 'relative',
  minWidth: '1000px',
  minHeight: '800px',
  background: 'radial-gradient(circle at center, #1e293b 0%, #0f172a 100%)'
},

// Rest of the styles remain the same as previous...
legend: {
  position: 'absolute',
  bottom: '20px',
  right: '20px',
  backgroundColor: 'rgba(30, 41, 59, 0.95)',
  border: '1px solid #334155',
  borderRadius: '12px',
  padding: '16px',
  backdropFilter: 'blur(10px)',
  boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
  zIndex: 40
},

legendTitle: {
  color: '#e2e8f0',
  fontSize: '14px',
  fontWeight: '600',
  marginBottom: '12px',
  textAlign: 'center',
  borderBottom: '1px solid #334155',
  paddingBottom: '8px'
},

legendItems: {
  display: 'flex',
  flexDirection: 'column',
  gap: '8px'
},

legendItem: {
  display: 'flex',
  alignItems: 'center',
  gap: '10px',
  fontSize: '12px',
  color: '#cbd5e1'
},

legendColor: {
  width: '16px',
  height: '4px',
  borderRadius: '2px',
  border: '1px solid rgba(255,255,255,0.2)'
},

legendIcon: {
  fontSize: '14px',
  width: '16px',
  textAlign: 'center'
},

noVisualization: {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  height: '100%',
  color: '#94a3b8',
  textAlign: 'center',
  padding: '40px'
},

noVisualizationIcon: {
  fontSize: '48px',
  marginBottom: '15px',
  opacity: 0.5
},

noVisualizationText: {
  fontSize: '14px',
  lineHeight: '1.5'
}
  
};

// Add CSS animation for loading spinner and connection arrows
const spinnerStyle = document.createElement('style');
spinnerStyle.textContent = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  
  #connectionArrow {
    marker-width: 10;
    marker-height: 7;
    ref-x: 9;
    ref-y: 3.5;
    orient: auto;
  }
  
  #connectionArrow polygon {
    fill: #94a3b8;
  }
`;
document.head.appendChild(spinnerStyle);

export default App;